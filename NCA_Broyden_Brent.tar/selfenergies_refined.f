************************************************************************
*****************************SIGMAF*************************************
************************************************************************
      SUBROUTINE SIGMAF(beta,rexp,abm,abp,omega,n,sefmnew,sefpnew)
      IMPLICIT NONE

      INTEGER n
      INTEGER i,j,k,kk,m,l,idx
      DOUBLE PRECISION beta
      DOUBLE PRECISION omega(n),abm(n),abp(n)
      DOUBLE PRECISION sefmnew(n),sefpnew(n)
      DOUBLE PRECISION rexp(n/2)

      DOUBLE PRECISION cspec,ferm0
      EXTERNAL cspec,ferm0

      DOUBLE PRECISION aux
      DOUBLE PRECISION exom
      DOUBLE PRECISION om1,om2,u1,u2
      DOUBLE PRECISION wert1,wert2,wertn
      DOUBLE PRECISION freq1,freq2
      DOUBLE PRECISION wspec1,wspec2,wf1,wf2

C     Cached endpoint values on the base grid for efficiency
      DOUBLE PRECISION specm(n)
      DOUBLE PRECISION fpos(n), fneg(n)

C     Optional: slopes for fast interpolation on each omega interval
      DOUBLE PRECISION dabm(n-1), dabp(n-1)
      INTEGER t

C----- Precompute caches that do NOT depend on exom
      DO t=1,n
         specm(t) = cspec(-omega(t))
         fpos(t)  = ferm0( beta*omega(t))
         fneg(t)  = ferm0(-beta*omega(t))
      END DO

      DO t=1,n-1
         dabm(t) = (abm(t+1)-abm(t)) / (omega(t+1)-omega(t))
         dabp(t) = (abp(t+1)-abp(t)) / (omega(t+1)-omega(t))
      END DO

C==================== negative external frequencies ====================
      DO i=1,n/2
         exom = omega(i)
         aux  = 0.0D0

C        Walking index for locating u = omega + exom in omega-grid
         idx = 1

         DO 100 j=1,n-1
            om1 = omega(j)
            om2 = omega(j+1)

            u1  = om1 + exom
            u2  = om2 + exom

C           Routine-B boundary behavior: skip if shifted endpoints out of range
            IF (u1 .LT. omega(1) .OR. u1 .GT. omega(n)) GOTO 100
            IF (u2 .LT. omega(1) .OR. u2 .GT. omega(n)) GOTO 100

C           Locate m such that omega(m) <= u1 <= omega(m+1)
            IF (idx .LT. 1) idx = 1
            IF (idx .GT. n-1) idx = n-1
 110        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u1) THEN
               idx = idx + 1
               GOTO 110
            ENDIF
 111        IF (idx .GT. 1 .AND. omega(idx) .GT. u1) THEN
               idx = idx - 1
               GOTO 111
            ENDIF
            m = idx

            wert1 = abm(m) + dabm(m)*(u1-omega(m))

C           Locate l such that omega(l) <= u2 <= omega(l+1) (continue walking)
 120        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u2) THEN
               idx = idx + 1
               GOTO 120
            ENDIF
 121        IF (idx .GT. 1 .AND. omega(idx) .GT. u2) THEN
               idx = idx - 1
               GOTO 121
            ENDIF
            l = idx

            wert2 = abm(l) + dabm(l)*(u2-omega(l))

            kk = l - m
            freq1 = om1

            IF (kk .EQ. 0) THEN
C              Endpoint weights are cached at grid points
               wspec1 = specm(j)
               wspec2 = specm(j+1)
               wf1    = fneg(j)
               wf2    = fneg(j+1)

               aux = aux + 0.5D0*(om2-om1) *
     &              ( wspec2*wf2*wert2 + wspec1*wf1*wert1 )

            ELSE
C              Refined integration: insert points where u crosses omega knots
C              For k=1..kk: freq2 = omega(m+k) - exom gives u = omega(m+k)
               DO 200 k=1,kk
                  freq2 = omega(m+k) - exom
                  wertn = abm(m+k)

C                 spec and ferm at non-grid freq2 need direct calls
                  aux = aux + 0.5D0*(freq2-freq1) *
     &                 ( cspec(-freq2)*ferm0(-beta*freq2)*wertn
     &                 + cspec(-freq1)*ferm0(-beta*freq1)*wert1 )

                  freq1 = freq2
                  wert1 = wertn
 200           CONTINUE

C              Last segment to om2 (endpoint at omega(j+1) is cached)
               aux = aux + 0.5D0*(om2-freq1) *
     &              ( specm(j+1)*fneg(j+1)*wert2
     &              + cspec(-freq1)*ferm0(-beta*freq1)*wert1 )
            ENDIF

 100     CONTINUE

         sefmnew(i) = aux
      END DO

C==================== positive external frequencies ====================
      DO i=n/2+1,n
         exom = omega(i)
         aux  = 0.0D0
         idx  = 1

         DO 300 j=1,n-1
            om1 = omega(j)
            om2 = omega(j+1)

            u1  = om1 + exom
            u2  = om2 + exom

            IF (u1 .LT. omega(1) .OR. u1 .GT. omega(n)) GOTO 300
            IF (u2 .LT. omega(1) .OR. u2 .GT. omega(n)) GOTO 300

            IF (idx .LT. 1) idx = 1
            IF (idx .GT. n-1) idx = n-1
 310        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u1) THEN
               idx = idx + 1
               GOTO 310
            ENDIF
 311        IF (idx .GT. 1 .AND. omega(idx) .GT. u1) THEN
               idx = idx - 1
               GOTO 311
            ENDIF
            m = idx

            wert1 = abp(m) + dabp(m)*(u1-omega(m))

 320        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u2) THEN
               idx = idx + 1
               GOTO 320
            ENDIF
 321        IF (idx .GT. 1 .AND. omega(idx) .GT. u2) THEN
               idx = idx - 1
               GOTO 321
            ENDIF
            l = idx

            wert2 = abp(l) + dabp(l)*(u2-omega(l))

            kk = l - m
            freq1 = om1

            IF (kk .EQ. 0) THEN
               wspec1 = specm(j)
               wspec2 = specm(j+1)
               wf1    = fpos(j)
               wf2    = fpos(j+1)

               aux = aux + 0.5D0*(om2-om1) *
     &              ( wspec2*wf2*wert2 + wspec1*wf1*wert1 )

            ELSE
               DO 400 k=1,kk
                  freq2 = omega(m+k) - exom
                  wertn = abp(m+k)

                  aux = aux + 0.5D0*(freq2-freq1) *
     &                 ( cspec(-freq2)*ferm0(beta*freq2)*wertn
     &                 + cspec(-freq1)*ferm0(beta*freq1)*wert1 )

                  freq1 = freq2
                  wert1 = wertn
 400           CONTINUE

               aux = aux + 0.5D0*(om2-freq1) *
     &              ( specm(j+1)*fpos(j+1)*wert2
     &              + cspec(-freq1)*ferm0(beta*freq1)*wert1 )
            ENDIF

 300     CONTINUE

         sefpnew(i) = aux
      END DO

C----- preserve your original symmetry/post-processing block
      DO i=1,n/2
         sefpnew(i)      = rexp(i)*sefmnew(i)
         sefmnew(i+n/2)  = rexp(n/2-i+1)*sefpnew(i+n/2)
      END DO

      RETURN
      END





************************************************************************
*****************************SIGMAB*************************************
************************************************************************
      SUBROUTINE SIGMAB(beta,rexp,afm,afp,omega,n,sebmnew,sebpnew)
      IMPLICIT NONE

      INTEGER n
      INTEGER i,j,k,kk,m,l,idx
      DOUBLE PRECISION beta
      DOUBLE PRECISION omega(n),afm(n),afp(n)
      DOUBLE PRECISION sebmnew(n),sebpnew(n)
      DOUBLE PRECISION rexp(n/2)

      DOUBLE PRECISION cspec,ferm0
      EXTERNAL cspec,ferm0

      DOUBLE PRECISION aux
      DOUBLE PRECISION exom
      DOUBLE PRECISION om1,om2,u1,u2
      DOUBLE PRECISION wert1,wert2,wertn
      DOUBLE PRECISION freq1,freq2
      DOUBLE PRECISION wspec1,wspec2,wf1,wf2

C     Cached endpoint values on the base grid for efficiency
      DOUBLE PRECISION specp(n)
      DOUBLE PRECISION fpos(n), fneg(n)

C     Optional: slopes for fast interpolation on each omega interval
      DOUBLE PRECISION dafm(n-1), dafp(n-1)
      INTEGER t

C----- Precompute caches that do NOT depend on exom
      DO t=1,n
         specp(t) = cspec( omega(t))
         fpos(t)  = ferm0( beta*omega(t))
         fneg(t)  = ferm0(-beta*omega(t))
      END DO

      DO t=1,n-1
         dafm(t) = (afm(t+1)-afm(t)) / (omega(t+1)-omega(t))
         dafp(t) = (afp(t+1)-afp(t)) / (omega(t+1)-omega(t))
      END DO

C==================== negative external frequencies ====================
      DO i=1,n/2
         exom = omega(i)
         aux  = 0.0D0
         idx  = 1

         DO 100 j=1,n-1
            om1 = omega(j)
            om2 = omega(j+1)

            u1  = om1 + exom
            u2  = om2 + exom

            IF (u1 .LT. omega(1) .OR. u1 .GT. omega(n)) GOTO 100
            IF (u2 .LT. omega(1) .OR. u2 .GT. omega(n)) GOTO 100

            IF (idx .LT. 1) idx = 1
            IF (idx .GT. n-1) idx = n-1
 110        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u1) THEN
               idx = idx + 1
               GOTO 110
            ENDIF
 111        IF (idx .GT. 1 .AND. omega(idx) .GT. u1) THEN
               idx = idx - 1
               GOTO 111
            ENDIF
            m = idx

            wert1 = afm(m) + dafm(m)*(u1-omega(m))

 120        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u2) THEN
               idx = idx + 1
               GOTO 120
            ENDIF
 121        IF (idx .GT. 1 .AND. omega(idx) .GT. u2) THEN
               idx = idx - 1
               GOTO 121
            ENDIF
            l = idx

            wert2 = afm(l) + dafm(l)*(u2-omega(l))

            kk = l - m
            freq1 = om1

            IF (kk .EQ. 0) THEN
               wspec1 = specp(j)
               wspec2 = specp(j+1)
               wf1    = fneg(j)
               wf2    = fneg(j+1)

               aux = aux + 0.5D0*(om2-om1) *
     &              ( wspec2*wf2*wert2 + wspec1*wf1*wert1 )

            ELSE
               DO 200 k=1,kk
                  freq2 = omega(m+k) - exom
                  wertn = afm(m+k)

                  aux = aux + 0.5D0*(freq2-freq1) *
     &                 ( cspec(freq2)*ferm0(-beta*freq2)*wertn
     &                 + cspec(freq1)*ferm0(-beta*freq1)*wert1 )

                  freq1 = freq2
                  wert1 = wertn
 200           CONTINUE

               aux = aux + 0.5D0*(om2-freq1) *
     &              ( specp(j+1)*fneg(j+1)*wert2
     &              + cspec(freq1)*ferm0(-beta*freq1)*wert1 )
            ENDIF

 100     CONTINUE

         sebmnew(i) = aux
      END DO

C==================== positive external frequencies ====================
      DO i=n/2+1,n
         exom = omega(i)
         aux  = 0.0D0
         idx  = 1

         DO 300 j=1,n-1
            om1 = omega(j)
            om2 = omega(j+1)

            u1  = om1 + exom
            u2  = om2 + exom

            IF (u1 .LT. omega(1) .OR. u1 .GT. omega(n)) GOTO 300
            IF (u2 .LT. omega(1) .OR. u2 .GT. omega(n)) GOTO 300

            IF (idx .LT. 1) idx = 1
            IF (idx .GT. n-1) idx = n-1
 310        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u1) THEN
               idx = idx + 1
               GOTO 310
            ENDIF
 311        IF (idx .GT. 1 .AND. omega(idx) .GT. u1) THEN
               idx = idx - 1
               GOTO 311
            ENDIF
            m = idx

            wert1 = afp(m) + dafp(m)*(u1-omega(m))

 320        IF (idx .LT. n-1 .AND. omega(idx+1) .LT. u2) THEN
               idx = idx + 1
               GOTO 320
            ENDIF
 321        IF (idx .GT. 1 .AND. omega(idx) .GT. u2) THEN
               idx = idx - 1
               GOTO 321
            ENDIF
            l = idx

            wert2 = afp(l) + dafp(l)*(u2-omega(l))

            kk = l - m
            freq1 = om1

            IF (kk .EQ. 0) THEN
               wspec1 = specp(j)
               wspec2 = specp(j+1)
               wf1    = fpos(j)
               wf2    = fpos(j+1)

               aux = aux + 0.5D0*(om2-om1) *
     &              ( wspec2*wf2*wert2 + wspec1*wf1*wert1 )

            ELSE
               DO 400 k=1,kk
                  freq2 = omega(m+k) - exom
                  wertn = afp(m+k)

                  aux = aux + 0.5D0*(freq2-freq1) *
     &                 ( cspec(freq2)*ferm0(beta*freq2)*wertn
     &                 + cspec(freq1)*ferm0(beta*freq1)*wert1 )

                  freq1 = freq2
                  wert1 = wertn
 400           CONTINUE

               aux = aux + 0.5D0*(om2-freq1) *
     &              ( specp(j+1)*fpos(j+1)*wert2
     &              + cspec(freq1)*ferm0(beta*freq1)*wert1 )
            ENDIF

 300     CONTINUE

         sebpnew(i) = aux
      END DO

C----- preserve your original symmetry/post-processing block
      DO i=1,n/2
         sebpnew(i)      = rexp(i)*sebmnew(i)
         sebmnew(i+n/2)  = rexp(n/2-i+1)*sebpnew(i+n/2)
      END DO

      RETURN
      END
      
