      PROGRAM NCA
      IMPLICIT REAL*8 (a-h,o-y)
      CHARACTER(len=3) check
      INTEGER nspin
      INTEGER N,nadd,naux,ngrid,ngrid2,N1,N2 !Grid parameters, ngrid=#gridpoints
      INCLUDE 'PARAMETER' 
      PARAMETER (naux=N+(N-1)*nadd,ngrid2=2*naux,ngrid=ngrid2+2*N1+2*N2)
      PARAMETER (nspin=2)
      INTEGER i,j,k,l,i0,ngrid3
      INTEGER iterate,maxiterate,kount
      DOUBLE PRECISION pi,xdelta
      PARAMETER(pi=3.1415926535898d0)
      PARAMETER(xdelta=1.0d-12)
      DOUBLE PRECISION temp,beta,D,hybrid,eps,xupdt
      DOUBLE PRECISION Gamma    !grid parameter
      DOUBLE PRECISION delta,x,xxx,xx0,xtol
      DOUBLE PRECISION omega(ngrid),gam_arr(ngrid2),freq(NGRID2)
      DOUBLE PRECISION sefp(ngrid),sefm(ngrid),afp(ngrid),afm(ngrid),
     &     gfr(ngrid),sefr(ngrid),sefmnew(ngrid),sefpnew(ngrid),
     &     sefmold(ngrid),sefpold(ngrid),afold(ngrid),
     &     sefrnew(ngrid),sebrnew(ngrid)
      DOUBLE PRECISION sebp(ngrid),sebm(ngrid),abp(ngrid),abm(ngrid),
     &     gbr(ngrid),sebr(ngrid),sebmnew(ngrid),sebpnew(ngrid),
     &     sebmold(ngrid),sebpold(ngrid),abold(ngrid)
      DOUBLE PRECISION rexp(ngrid/2)
      DOUBLE PRECISION ad1(ngrid),ad2(ngrid),ad(ngrid),gdr(ngrid) 
      DOUBLE PRECISION scr(ngrid/2),out,aux(ngrid)
      DOUBLE PRECISION suszi(ngrid),resus(ngrid)
      DOUBLE PRECISION templist(100)
      DOUBLE PRECISION Fmatrix(500,2*ngrid+1),Vmatrix(500,2*ngrid+1),
     &     Vout(2*ngrid+1)
      EXTERNAL cspec,ferm0
      CHARACTER*7 handle
      CHARACTER*11 name1,name2
      CHARACTER*15 name3
**********************READ IN PARAMETERS********************************
      OPEN(UNIT=14,FILE='PARAMETER.dat',STATUS='UNKNOWN')
      READ(14,*) temp0,D,eps,hybrid
      READ(14,*) Gamma
      READ(14,*) maxiterate,xtol,xupdt
      beta=1/temp
      CLOSE(14) 
************************************************************************ 
      OPEN(UNIT=20,FILE='TEMPLIST.dat',STATUS='UNKNOWN')
      k=0
      DO i=1,100
         READ(20,*,END=99) temp
         templist(i)=temp
         k=k+1
      END DO
 99   CONTINUE
      number=k
      
*************************************
      OPEN(UNIT=97,FILE='STATUS.dat',STATUS='UNKNOWN')

      DO lkm=1,number
      check='NOT'
      temp=templist(lkm)
*************************************
      beta=1/temp
*************************************
      WRITE(handle,'(E7.2)') temp
      name2='abp_'//handle
      name1='afp_'//handle
      OPEN(UNIT=91,FILE=name1,STATUS='UNKNOWN')
      OPEN(UNIT=92,FILE=name2,STATUS='UNKNOWN')
      name2='abm_'//handle
      name1='afm_'//handle
      OPEN(UNIT=93,FILE=name1,STATUS='UNKNOWN')
      OPEN(UNIT=94,FILE=name2,STATUS='UNKNOWN')
       name3='rlambda_'//handle
      OPEN(UNIT=95,FILE=name3,STATUS='UNKNOWN') 
********************build frequency grid omega**************************
      CALL GRID(Gamma,gam_arr,N,Nadd,naux,ngrid2,freq)
      CALL RENORM(D,ngrid2,freq)
      EPS1   = dabs(eps)
      SIGMA1 = eps1/5.0d0
      EPS2   = dabs(temp)
      SIGMA2 = eps2/10.0d0
      CALL BUILD_RESONANCE_GRID(freq,ngrid2,D,   
     &     EPS1,SIGMA1,N1,EPS2,SIGMA2,N2,
     &     omega,ngrid3)
************************************************************************
      
*************************initialize functions***************************
      CALL READIN(sefpold,sefmold,sebpold,sebmold,rlambd0,omega,ngrid)
      
      CALL KRAKRO(ngrid,omega,sefpold,sefr) !real part of selfenergies
      CALL KRAKRO(ngrid,omega,sebpold,sebr) !real part of selfenergies
      DO i=1,ngrid/2
         rexp(i)=dexp(beta*omega(i))
      END DO
      DO i=1,ngrid
         sefp(i)=sefpold(i)
         sebp(i)=sebpold(i)
         sefm(i)=sefmold(i)
         sebm(i)=sebmold(i)
      END DO
      DO i=1,ngrid/2
         sefp(i)=rexp(i)*sefm(i)
         sefm(i+ngrid/2)=rexp(ngrid/2-i+1)*sefp(i+ngrid/2)
         sebp(i)=rexp(i)*sebm(i)
         sebm(i+ngrid/2)=rexp(ngrid/2-i+1)*sebp(i+ngrid/2)
      END DO
************************************************************************
      DO i=1,ngrid/2
         k=i+ngrid/2
         afm(i)=sefmold(i)/
     &        ((omega(i)-eps+rlambd0-sefr(i))**2+sefpold(i)**2)
         afp(k)=sefpold(k)/
     &          ((omega(k)-eps+rlambd0-sefr(k))**2+sefpold(k)**2)
         abm(i)=sebmold(i)/
     &          ((omega(i)+rlambd0-sebr(i))**2+sebpold(i)**2)
         abp(k)=sebpold(k)/
     &          ((omega(k)+rlambd0-sebr(k))**2+sebpold(k)**2)
         afp(i)=rexp(i)*afm(i)
         abp(i)=rexp(i)*abm(i)
         afm(k)=rexp(ngrid/2-i+1)*afp(k)
         abm(k)=rexp(ngrid/2-i+1)*abp(k)
      END DO
************************************************************************
******************get DoS and Fermi function****************************
      CALL DOSINTERPOL
      CALL FERMIFUNC0
************************************************************************
************************************************************************
**********************START ITERATION***********************************
************************************************************************
************************************************************************
      DO iterate=1,maxiterate
         CALL SIGMAF(beta,rexp,abm,abp,omega,ngrid,sefmnew,sefpnew)
         CALL SIGMAB(beta,rexp,afm,afp,omega,ngrid,sebmnew,sebpnew)
         CALL DSCAL(ngrid,hybrid/pi,sefpnew,1)
         CALL DSCAL(ngrid,hybrid/pi,sefmnew,1)
         CALL DSCAL(ngrid,nspin*hybrid/pi,sebpnew,1)
         CALL DSCAL(ngrid,nspin*hybrid/pi,sebmnew,1)

         CALL KRAKRO(ngrid,omega,sefpnew,sefrnew) !real part of selfenergies
         CALL KRAKRO(ngrid,omega,sebpnew,sebrnew) !real part of selfenergies
         rlambold=rlambd0
C        print*,rlambd0
C         CALL RUPDATE(rexp,sefpnew,sefmnew,sefrnew,sebpnew,sebmnew,
C     +        sebrnew,omega,beta,eps,rlambd0,delta)


           rint=2.0d0*pi
         CALL RLAMBDAPDT(rexp,sefpnew,sefmnew,sefrnew,sebpnew,sebmnew,
     +        sebrnew,omega,beta,eps,
     +        rlambd0,rint,xxx)
            rlambd0=xxx
            WRITE(61,*) iterate,xxx
***********************update selfenergies******************************
*********************** use Broyden ************************************
         IF(iterate.LE.500) THEN
            kount=iterate
            DO i=1,ngrid/2
               Vmatrix(kount,i)=sefm(i)
               Vmatrix(kount,i+ngrid/2)=sefp(i+ngrid/2)
               Vmatrix(kount,i+ngrid)=sebm(i)
               Vmatrix(kount,i+ngrid+ngrid/2)=sebp(i+ngrid/2)
               Fmatrix(kount,i)=sefmnew(i)-sefm(i)
               Fmatrix(kount,i+ngrid/2)=sefpnew(i+ngrid/2)
     +              -sefp(i+ngrid/2)
               Fmatrix(kount,i+ngrid)=sebmnew(i)-sebm(i)
               Fmatrix(kount,i+ngrid+ngrid/2)=sebpnew(i+ngrid/2)
     +              -sebp(i+ngrid/2)
            END DO
            Vmatrix(kount,2*ngrid+1)=rlambold
            Fmatrix(kount,2*ngrid+1)=rlambd0-rlambold
         ELSE
            kount=500
            DO l=2,kount
               DO i=1,ngrid/2
                  Vmatrix(l-1,i)=Vmatrix(l,i)
                  Vmatrix(l-1,i+ngrid/2)=Vmatrix(l,i+ngrid/2)
                  Vmatrix(l-1,i+ngrid)=Vmatrix(l,i+ngrid)
                  Vmatrix(l-1,i+3*ngrid/2)=Vmatrix(l,i+3*ngrid/2)
                  Fmatrix(l-1,i)=Fmatrix(l,i)
                  Fmatrix(l-1,i+ngrid/2)=Fmatrix(l,i+ngrid/2)
                  Fmatrix(l-1,i+ngrid)=Fmatrix(l,i+ngrid)
                  Fmatrix(l-1,i+3*ngrid/2)=Fmatrix(l,i+3*ngrid/2)
               END DO
               Vmatrix(l-1,2*ngrid+1)=Vmatrix(l,2*ngrid+1)
               Fmatrix(l-1,2*ngrid+1)=Fmatrix(l,2*ngrid+1)
            END DO
            DO i=1,ngrid/2
               Vmatrix(kount,i)=sefm(i)
               Vmatrix(kount,i+ngrid/2)=sefp(i+ngrid/2)
               Vmatrix(kount,i+ngrid)=sebm(i)
               Vmatrix(kount,i+ngrid+ngrid/2)=sebp(i+ngrid/2)
               Fmatrix(kount,i)=sefmnew(i)-sefm(i)
               Fmatrix(kount,i+ngrid/2)=sefpnew(i+ngrid/2)
     +              -sefp(i+ngrid/2)
               Fmatrix(kount,i+ngrid)=sebmnew(i)-sebm(i)
               Fmatrix(kount,i+ngrid+ngrid/2)=sebpnew(i+ngrid/2)
     +              -sebp(i+ngrid/2)
            END DO
            Vmatrix(kount,2*ngrid+1)=rlambold
            Fmatrix(kount,2*ngrid+1)=rlambd0-rlambold
         ENDIF


         CALL BROYDEN_f77(kount,2*ngrid+1,500,Fmatrix,Vmatrix,Vout,info)
         
         DO i=1,ngrid/2
            sefm(i)=Vout(i)
            sefp(i)=rexp(i)*sefm(i)
            sefp(i+ngrid/2)=Vout(i+ngrid/2)
            sefm(i+ngrid/2)=rexp(ngrid/2-i+1)*sefp(i+ngrid/2)
            sebm(i)=Vout(i+ngrid)
            sebp(i)=rexp(i)*sebm(i)
            sebp(i+ngrid/2)=Vout(i+ngrid+ngrid/2)
            sebm(i+ngrid/2)=rexp(ngrid/2-i+1)*sebp(i+ngrid/2)
         END DO
         rlambd0=Vout(2*ngrid+1)

c         DO i=1,ngrid
c            sefp(i)=(xupdt*sefpnew(i)+sefpold(i))/(1.0d0+xupdt)
c            sefpold(i)=sefp(i)
c            sefm(i)=(xupdt*sefmnew(i)+sefmold(i))/(1.0d0+xupdt)
c            sefmold(i)=sefm(i)
c            sebp(i)=(xupdt*sebpnew(i)+sebpold(i))/(1.0d0+xupdt)
c            sebpold(i)=sebp(i)
c            sebm(i)=(xupdt*sebmnew(i)+sebmold(i))/(1.0d0+xupdt)
c            sebmold(i)=sebm(i)
c            afold(i)=afp(i)
c            abold(i)=abp(i)
c         END DO
c         print*, rlambd0,rlambold
c         stop

************************************************************************
******************calculate rlambda0 update*****************************
c         rlambold=rlambd0
c         CALL RUPDATE(rexp,sefp,sefm,sefr,sebp,sebm,sebr,omega,beta,eps,
c     +        rlambd0,delta)

c         CALL SHIFT(delta,omega,ngrid,sefp,sefm,sefr,sebp,sebm,sebr)

         CALL KRAKRO(ngrid,omega,sefp,sefr) !real part of selfenergies
         CALL KRAKRO(ngrid,omega,sebp,sebr) !real part of selfenergies
         DO i=1,ngrid
            afold(i)=afp(i)
            abold(i)=abp(i)
         END DO
*********************** end Broyden ************************************
************************************************************************
****************calculate new spectral functions************************
         DO i=1,ngrid/2
            k=i+ngrid/2
            afm(i)=sefm(i)/
     &           ((omega(i)-eps+rlambd0-sefr(i))**2+sefp(i)**2)
            afp(k)=sefp(k)/
     &           ((omega(k)-eps+rlambd0-sefr(k))**2+sefp(k)**2)
            abm(i)=sebm(i)/
     &           ((omega(i)+rlambd0-sebr(i))**2+sebp(i)**2)
            abp(k)=sebp(k)/
     &           ((omega(k)+rlambd0-sebr(k))**2+sebp(k)**2)
            afp(i)=rexp(i)*afm(i)
            abp(i)=rexp(i)*abm(i)
            afm(k)=rexp(ngrid/2-i+1)*afp(k)
            abm(k)=rexp(ngrid/2-i+1)*abp(k)
         END DO

         CALL KRAKRO(ngrid,omega,afp,gfr) !real part of GF
         CALL KRAKRO(ngrid,omega,abp,gbr) !real part of GF
         CALL ROUT('afp.dat',ngrid,omega,afp)
         CALL ROUT('afm.dat',ngrid,omega,afm)
         CALL ROUT('abp.dat',ngrid,omega,abp)
         CALL ROUT('abm.dat',ngrid,omega,abm)
************************************************************************
         DO i=1,ngrid
            aux(i)=afp(i)+afm(i)
         END DO
         CALL PN(delta,beta,ngrid,omega,aux,rnf)
         DO i=1,ngrid
            aux(i)=abp(i)+abm(i)
         END DO
         CALL PN(delta,beta,ngrid,omega,aux,rnb)
********************CHECK for CONVERGENCE*******************************
         xx0=0.0d0
         DO i=1,ngrid
            xxx=dabs(afp(i)-afold(i))/(afp(i)+1.0d-33)
cc            xxx=dabs(afp(i)-afold(i))
            IF(xxx.GT.xx0) THEN
            xx0=xxx
            i0=i
            ENDIF
            xxx=dabs(abp(i)-abold(i))/(abp(i)+1.0d-33)
cc            xxx=dabs(abp(i)-abold(i))
            IF(xxx.GT.xx0) THEN
               xx0=xxx
               i0=i
            ENDIF
         END DO
         print*,'------------------------'
         print*,'iteration ', iterate, ' of ', maxiterate
         print*,'overall change= ',xx0, omega(i0)
         print*,'constraint=      ',2.0*rnf+rnb
         print*,'Besetzung=      ',rnf
         print*,'------------------------'
         IF(xx0.LT.xtol) THEN
            check='YES'
            GOTO 300
         END IF

      END DO
 300  CONTINUE
      
      WRITE(97,*) temp,check,iterate,xtol,2.0*rnf+rnb,2.0*rnf
      
*******************************************************************
           DO i=1,ngrid
                 WRITE(91,*) omega(i),afp(i),temp
                 WRITE(92,*) omega(i),abp(i),temp
                 WRITE(93,*) omega(i),afm(i),temp
                 WRITE(94,*) omega(i),abm(i),temp
           END DO
           WRITE(95,*) rlambd0
           CLOSE(91)
           CLOSE(92)
           CLOSE(93)
           CLOSE(94)
           CLOSE(95)
*******************************************************************
      CALL ROUT('SEBM.dat',ngrid,omega,sebm)
      CALL ROUT('SEBP.dat',ngrid,omega,sebp)
      CALL ROUT('SEFP.dat',ngrid,omega,sefp)
      CALL ROUT('SEFM.dat',ngrid,omega,sefm)
      OPEN(UNIT=15,FILE='RLAMBDA.dat',STATUS='UNKNOWN')
      WRITE(15,*) rlambd0
      CLOSE(15)
      

      CALL bubbleone(afp,abm,omega,ngrid,ad1)      
      CALL bubbletwo(abp,afm,omega,ngrid,ad2)
      DO i=1,ngrid
         ad(i)=ad1(i)+ad2(i)
      END DO
      CALL  KRAKRO(ngrid,omega,ad,gdr) !real part of GF
c       CALL OWNBUBBLE(omega,afp,abm,ad1)
c       CALL OWNBUBBLE(omega,afm,abp,ad2)
c      CALL OWNBUBBLE(omega,ngrid,omega,ngrid,afp,abm,ad1)
c      CALL OWNBUBBLE(omega,ngrid,omega,ngrid,afm,abp,ad2)
      OPEN(UNIT=19,FILE='dos.dat_'//handle,STATUS='UNKNOWN')
      DO i=1,ngrid
         write(19,*) omega(i),ad(i),gdr(i)
      END DO
      CLOSE(19)    

      END DO
      STOP
      END
      





************************************************************************
c                        pseudoparticle bubble
************************************************************************
*****************************pseudoparticle bubble**********************
************************************************************************
      SUBROUTINE bubbleone(abm,afp,omega,n,output)
      IMPLICIT NONE
      INTEGER i,j,k,kk,l,n,m,iscr(n)
      DOUBLE PRECISION aux,wert1,wert2,freq,aux2
      DOUBLE PRECISION freq1,freq2,wertn
      DOUBLE PRECISION exom,omex
      DOUBLE PRECISION Afermion
      DOUBLE PRECISION pi
      PARAMETER(pi=3.1415926535898d0)
      DOUBLE PRECISION omega(n),abm(n),afp(n)
      DOUBLE PRECISION output(n)      
      EXTERNAL Afermion

      
      DO i=1,n
         exom=omega(i)
         DO j=1,n
            omex=exom+omega(j)  !frequency argument of abm
            CALL locate(omega,n,omex,m)
            iscr(j)=m           !index of epsilon on eps+exom
         END DO
         aux=0.0d0
         m=iscr(1)
         IF(m.EQ.0) THEN
            wert1=0.0d0
         ELSEIF(m.EQ.n) THEN
            wert1=0.0d0
         ELSE
            wert1=abm(m)+(abm(m+1)-abm(m))/(omega(m+1)-omega(m))
     &           *(omega(1)+exom-omega(m)) !interpolate A_b
         ENDIF
         DO j=1,n-1             !integration loop
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCnegative freq
                                !if iscr(j)=iscr(j+1),no add. points
            l=iscr(j+1)
             m=iscr(j)
            kk=l-m
            IF(l.EQ.0) THEN
               wert2=0.0d0
            ELSEIF(l.EQ.n) THEN
               wert2=0.0d0
            ELSE
               wert2=abm(l)+(abm(l+1)-abm(l))/(omega(l+1)-omega(l))
     &              *(omega(j+1)+exom-omega(l)) !interpolate A_b
            ENDIF
            IF(kk.eq.0) THEN
               aux=aux+0.5*(omega(j+1)-omega(j))*
     &              (Afermion(omega(j+1),omega,afp)*wert2+
     &              Afermion(omega(j),omega,afp)*wert1)
c               write(59,*) omega(j),wert2
c               WRITE(61,*) -omega(j+1),Afermion(-omega(j+1),omega,afp)
            ELSE
cc            IF((m.eq.0).OR.(m.eq.n)) GOTO 20
               freq1=omega(j)
               DO k=1,kk
c                  write(86,*) omega(m+k)-exom,abm(m+k)
                  freq2=omega(m+k)-exom
                  wertn=abm(m+k)
                  aux=aux+0.5*(freq2-freq1)*
     &                 (Afermion(freq2,omega,afp)*wertn+
     &                 Afermion(freq1,omega,afp)*wert1)
                  freq1=freq2
                  wert1=wertn

               END DO
               aux=aux+0.5*(omega(j+1)-freq1)* !add last interval
     &              (Afermion(omega(j+1),omega,afp)*wert2+
     &              Afermion(freq1,omega,afp)*wert1)


            ENDIF
 20         CONTINUE
            wert1=wert2
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCnegative freq
         END DO
         output(i)=aux
      END DO
      
      DO i=1,n
         output(i)=output(i)/pi
      END DO
      
      RETURN
      END

***********************************************************************
***********************************************************************
      DOUBLE PRECISION FUNCTION Afermion(xxx,omega,afp)
      IMPLICIT NONE
      INTEGER N,nadd,naux,ngrid,ngrid2,N1,N2 !Grid parameters, ngrid=#gridpoints
      INTEGER nspin
c      INTEGER nNeu,new,ninter,neu,nB,ngmuB
      INCLUDE 'PARAMETER' 
      PARAMETER (naux=N+(N-1)*nadd,ngrid2=2*naux,ngrid=ngrid2+2*N1+2*N2)   
      PARAMETER (nspin=2)
c
c      INCLUDE 'PARAMETER'
c      PARAMETER (naux=N+(N-1)*nadd,nNeu=2*naux)
c      PARAMETER (ninter=nNeu+4*new)
c       PARAMETER (ngmuB=ninter+4*nB)
c      PARAMETER (ngrid=ngmuB+4*neu)
c
      INTEGER j0
      DOUBLE PRECISION xxx
      DOUBLE PRECISION afp(ngrid),omega(ngrid)
      
      

      CALL locate(omega,ngrid,xxx,j0)
      IF(j0.EQ.0) THEN
         Afermion=0.0d0
      ELSEIF(j0.EQ.ngrid) THEN
         Afermion=0.0d0
      ELSE
      Afermion=afp(j0)+(afp(j0+1)-afp(j0))/(omega(j0+1)-omega(j0))
     &           *(xxx-omega(j0))
      
      ENDIF      
      RETURN
      END
***********************************************************************
***********************************************************************
      SUBROUTINE bubbletwo(abm,afp,omega,n,output)
      IMPLICIT NONE
      INTEGER i,j,k,kk,l,n,m,iscr(n)
      DOUBLE PRECISION aux,wert1,wert2,freq,aux2
      DOUBLE PRECISION freq1,freq2,wertn
      DOUBLE PRECISION exom,omex
      DOUBLE PRECISION Afermion
      DOUBLE PRECISION pi
      PARAMETER(pi=3.1415926535898d0)
      DOUBLE PRECISION omega(n),abm(n),afp(n)
      DOUBLE PRECISION output(n)      
      EXTERNAL Afermion

      DO i=1,n
         exom=-omega(i)
         DO j=1,n
            omex=exom+omega(j)  !frequency argument of abm
            CALL locate(omega,n,omex,m)
            iscr(j)=m           !index of epsilon on eps+exom
         END DO
         aux=0.0d0
         m=iscr(1)
         IF(m.EQ.0) THEN
            wert1=0.0d0
         ELSEIF(m.EQ.n) THEN
            wert1=0.0d0
         ELSE
            wert1=abm(m)+(abm(m+1)-abm(m))/(omega(m+1)-omega(m))
     &           *(omega(1)+exom-omega(m)) !interpolate A_b
         ENDIF
         DO j=1,n-1             !integration loop
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCnegative freq
                                !if iscr(j)=iscr(j+1),no add. points
            l=iscr(j+1)
             m=iscr(j)
            kk=l-m
            IF(l.EQ.0) THEN
               wert2=0.0d0
            ELSEIF(l.EQ.n) THEN
               wert2=0.0d0
            ELSE
               wert2=abm(l)+(abm(l+1)-abm(l))/(omega(l+1)-omega(l))
     &              *(omega(j+1)+exom-omega(l)) !interpolate A_b
            ENDIF
            IF(kk.eq.0) THEN
               aux=aux+0.5*(omega(j+1)-omega(j))*
     &              (Afermion(omega(j+1),omega,afp)*wert2+
     &              Afermion(omega(j),omega,afp)*wert1)
c               write(59,*) omega(j),wert2
c               WRITE(61,*) -omega(j+1),Afermion(-omega(j+1),omega,afp)
            ELSE

cc            IF((m.eq.0).OR.(m.eq.n)) GOTO 20
               freq1=omega(j)
               DO k=1,kk
c                  write(86,*) omega(m+k)-exom,abm(m+k)
                  freq2=omega(m+k)-exom
                  wertn=abm(m+k)
                  aux=aux+0.5*(freq2-freq1)*
     &                 (Afermion(freq2,omega,afp)*wertn+
     &                 Afermion(freq1,omega,afp)*wert1)
                  freq1=freq2
                  wert1=wertn

               END DO
               aux=aux+0.5*(omega(j+1)-freq1)* !add last interval
     &              (Afermion(omega(j+1),omega,afp)*wert2+
     &              Afermion(freq1,omega,afp)*wert1)


            ENDIF
 20         CONTINUE
            wert1=wert2
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCnegative freq
         END DO
         output(i)=aux
      END DO
      
      DO i=1,n
         output(i)=output(i)/pi
      END DO
      
      RETURN
      END

***********************************************************************
