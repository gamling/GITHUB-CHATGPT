      DOUBLE PRECISION FUNCTION Qbstmng(delta)
C======================================================================
C  Refined trapezoidal integration of  ferm0(beta*omega) * xxx(omega+delta)
C  on base grid omega(:), where xxx(:) is linearly interpolated in omega.
C
C  Refinement: when omega+delta crosses an interpolation knot omega(k),
C  we split the interval at omega = omega(k) - delta (so xxx is exact at knot).
C
C  COMMON blocks are kept intact: /temp/ beta, /whtev/ omega, xxx
C
C  Boundary behavior (matches the spirit of old Routine B):
C    If either endpoint omega(j)+delta or omega(j+1)+delta is out of [omega(1),omega(ngrid)],
C    the interval is skipped (no partial clipping).
C======================================================================
      IMPLICIT NONE

      INTEGER :: ngrid,N,nadd,naux,N1,N2,ngrid2
      INCLUDE 'PARAMETER'
      PARAMETER (naux=N+(N-1)*nadd,ngrid2=2*naux,ngrid=ngrid2+2*N1+2*N2)

      DOUBLE PRECISION delta, beta
      DOUBLE PRECISION omega(ngrid), xxx(ngrid)
      COMMON /temp/  beta
      COMMON /whtev/ omega, xxx

      DOUBLE PRECISION ferm0
      EXTERNAL ferm0

      INTEGER j, m, l, kk, k, idx
      DOUBLE PRECISION aux, pi
      DOUBLE PRECISION u1, u2
      DOUBLE PRECISION x1, x2, xk
      DOUBLE PRECISION freq1, freq2
      DOUBLE PRECISION om1, om2

      PARAMETER (pi = 3.1415926535898D0)

      aux = 0.0D0

C     Walking index used to locate u in omega grid (assumes omega increasing).
      idx = 1

      DO 100 j = 1, ngrid-1

         om1 = omega(j)
         om2 = omega(j+1)

         u1  = om1 + delta
         u2  = om2 + delta

C        Skip interval if either shifted endpoint is out of interpolation domain.
         IF (u1 .LT. omega(1) .OR. u1 .GT. omega(ngrid)) GOTO 100
         IF (u2 .LT. omega(1) .OR. u2 .GT. omega(ngrid)) GOTO 100

C        -------- Locate interval index m for u1: omega(m) <= u1 <= omega(m+1)
C        Clamp idx into [1,ngrid-1]
         IF (idx .LT. 1) idx = 1
         IF (idx .GT. ngrid-1) idx = ngrid-1

 110     IF (idx .LT. ngrid-1 .AND. omega(idx+1) .LT. u1) THEN
            idx = idx + 1
            GOTO 110
         ENDIF
 111     IF (idx .GT. 1 .AND. omega(idx) .GT. u1) THEN
            idx = idx - 1
            GOTO 111
         ENDIF
         m = idx

C        Linear interpolation for x1 = xxx(u1)
         x1 = xxx(m) + (xxx(m+1)-xxx(m)) *
     &        (u1-omega(m)) / (omega(m+1)-omega(m))

C        -------- Locate interval index l for u2 (continue walking from idx)
 120     IF (idx .LT. ngrid-1 .AND. omega(idx+1) .LT. u2) THEN
            idx = idx + 1
            GOTO 120
         ENDIF
 121     IF (idx .GT. 1 .AND. omega(idx) .GT. u2) THEN
            idx = idx - 1
            GOTO 121
         ENDIF
         l = idx

C        Linear interpolation for x2 = xxx(u2)
         x2 = xxx(l) + (xxx(l+1)-xxx(l)) *
     &        (u2-omega(l)) / (omega(l+1)-omega(l))

C        Number of knots crossed by u from u1 to u2 in omega-space
         kk = l - m

C        Integrate over freq in [om1, om2], refining at freq = omega(m+k)-delta
         freq1 = om1

         IF (kk .EQ. 0) THEN
C           No knot crossing: plain trapezoid on [om1, om2]
            aux = aux + 0.5D0*(om2-om1) *
     &            ( ferm0(beta*om2)*x2 + ferm0(beta*om1)*x1 )

         ELSE
C           Crosses one or more knots: insert sub-intervals at each knot
C           For k=1..kk, the point freq2 = omega(m+k) - delta gives u = omega(m+k)
C           so xxx is exactly xxx(m+k) (no interpolation error at the knot).
            DO 200 k = 1, kk
               freq2 = omega(m+k) - delta
               xk    = xxx(m+k)

               aux = aux + 0.5D0*(freq2-freq1) *
     &               ( ferm0(beta*freq2)*xk + ferm0(beta*freq1)*x1 )

               freq1 = freq2
               x1    = xk
 200        CONTINUE

C           Add final segment from last inserted knot to om2 using x2 at endpoint
            aux = aux + 0.5D0*(om2-freq1) *
     &            ( ferm0(beta*om2)*x2 + ferm0(beta*freq1)*x1 )

         ENDIF

 100  CONTINUE

      Qbstmng = aux/pi - 1.0D0
      RETURN
      END

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
!      DOUBLE PRECISION FUNCTION Qbstmng(delta)
!      IMPLICIT NONE
!
!      INTEGER :: ngrid,N,nadd,naux,new,nNeu,ninter,ntemp
!      INCLUDE 'PARAMETER'
!      PARAMETER (naux=N+(N-1)*nadd,nNeu=2*naux)
!      PARAMETER (ninter=nNeu+4*new)
!      PARAMETER (ngrid=ninter+4*ntemp)
!
!      INTEGER :: PV_MODE
!      PARAMETER (PV_MODE = 0)
!
!      INTEGER j, idx
!      DOUBLE PRECISION delta, beta
!      DOUBLE PRECISION omega(ngrid), xxx(ngrid)
!      DOUBLE PRECISION wgt(ngrid)
!      COMMON /wgtblk/ wgt
!      DOUBLE PRECISION aux, pi
!      DOUBLE PRECISION w1, w2, du
!      DOUBLE PRECISION x1, x2
!      DOUBLE PRECISION u1, u2
!
!      DOUBLE PRECISION ferm0
!      EXTERNAL ferm0
!
!      COMMON /temp/  beta
!      COMMON /whtev/ omega, xxx
!
!      PARAMETER (pi = 3.1415926535898d0)
!
!      aux = 0.0d0
!
!      IF (PV_MODE .EQ. 0) THEN
!
!         idx = 1
!
!         DO j=1,ngrid-1
!            du = omega(j+1) - omega(j)
!
C           ---- Evaluate xxx(omega(j) + delta)
!            u1 = omega(j) + delta
!
!            IF (u1 .LT. omega(1) .OR. u1 .GT. omega(ngrid)) THEN
!               x1 = 0.0d0
!
!            ELSEIF (u1 .EQ. omega(1)) THEN
!               x1 = xxx(1)
!
!            ELSEIF (u1 .EQ. omega(ngrid)) THEN
!               x1 = xxx(ngrid)
!
!            ELSE
! 1010          IF (idx .LT. ngrid-1 .AND. omega(idx+1) .LT. u1) THEN
!                  idx = idx + 1
!                  GOTO 1010
!               ENDIF
! 1011          IF (idx .GT. 1 .AND. omega(idx) .GT. u1) THEN
!                  idx = idx - 1
!                  GOTO 1011
!               ENDIF
!
C              Now omega(idx) <= u1 <= omega(idx+1) with idx in [1,ngrid-1]
!               x1 = xxx(idx) + (xxx(idx+1)-xxx(idx)) *
!     &              (u1-omega(idx)) / (omega(idx+1)-omega(idx))
!            ENDIF
!
C           ---- Evaluate xxx(omega(j+1) + delta)
!            u2 = omega(j+1) + delta
!
!            IF (u2 .LT. omega(1) .OR. u2 .GT. omega(ngrid)) THEN
!               x2 = 0.0d0
!
!            ELSEIF (u2 .EQ. omega(1)) THEN
!               x2 = xxx(1)
!
!            ELSEIF (u2 .EQ. omega(ngrid)) THEN
!               x2 = xxx(ngrid)
!
!            ELSE
! 1020          IF (idx .LT. ngrid-1 .AND. omega(idx+1) .LT. u2) THEN
!                  idx = idx + 1
!                  GOTO 1020
!               ENDIF
! 1021          IF (idx .GT. 1 .AND. omega(idx) .GT. u2) THEN
!                  idx = idx - 1
!                  GOTO 1021
!               ENDIF
!
!               x2 = xxx(idx) + (xxx(idx+1)-xxx(idx)) *
!     &              (u2-omega(idx)) / (omega(idx+1)-omega(idx))
!            ENDIF
!
C           ---- Weight at endpoints (placeholder)
!            w1 = wgt(j)
!            w2 = wgt(j+1)
!
!            aux = aux + 0.5d0*du*(w2*x2 + w1*x1)
!         END DO
!
!      ELSE
C        PV_MODE branch unchanged here (but uses corrected XSHIFT below)
C        ...
!      ENDIF
!
!      Qbstmng = aux/pi - 1.0d0
!      RETURN
!      END

C****************************************************************************
C****************************************************************************
      SUBROUTINE XSHIFT(omega,xxx,ngrid,u,xout)
      IMPLICIT NONE
      INTEGER ngrid, idx
      DOUBLE PRECISION omega(ngrid), xxx(ngrid)
      DOUBLE PRECISION u, xout
      DOUBLE PRECISION tol
      DOUBLE PRECISION tolL, tolR
      
C     Option A boundary policy:
C       xout = 0 for u < omega(1) or u > omega(ngrid)
C       xout = xxx(1) at u = omega(1)
C       xout = xxx(ngrid) at u = omega(ngrid)
C       else linear interpolation on interior

      tol  = 1.0d-12
      tolL = tol*DMAX1(1.0d0, DABS(omega(1)))
      tolR = tol*DMAX1(1.0d0, DABS(omega(ngrid)))

C     ---- Outside support
      IF (u .LT. omega(1)-tolL .OR. u .GT. omega(ngrid)+tolR) THEN
         xout = 0.0d0
         RETURN
      ENDIF

C     ---- Snap to left endpoint
      IF (DABS(u-omega(1)) .LE. tolL) THEN

         xout = xxx(1)
         RETURN
      ENDIF

C     ---- Snap to right endpoint
      IF (DABS(u-omega(ngrid)) .LE. tolR) THEN

         xout = xxx(ngrid)
         RETURN
      ENDIF

C     Interior point: locate bracketing index 1 <= idx <= ngrid-1
      CALL locate(omega, ngrid, u, idx)

      IF (idx .LT. 1) THEN
         xout = xxx(1)
      ELSEIF (idx .GE. ngrid) THEN
         xout = xxx(ngrid)
      ELSE
         xout = xxx(idx) + (xxx(idx+1)-xxx(idx)) *
     &          (u-omega(idx)) / (omega(idx+1)-omega(idx))
      ENDIF

      RETURN
      END
C****************************************************************************
C****************************************************************************

C  PV_CELL
C
C  Add trapezoid contribution on a positive ω-interval [op1,op2] using
C  PV integrand (H(ω)-H(-ω))/ω.
C
C  Inputs:
C    op1, op2  : positive ω endpoints (op1>0, op2>0)
C    on1, on2  : paired negative ω endpoints (should be <0)
C  Accumulates into 'aux'.
C
C  Notes:
C   - This routine uses g(ω)=1 placeholder. Replace with your gfun.
C   - Uses xxx(u)=0 outside grid and linear interpolation inside.
C======================================================================

      SUBROUTINE PV_CELL(omega,xxx,ngrid,delta,beta,op1,op2,on1,on2,aux)
      IMPLICIT NONE
      INTEGER :: ngrid, idx
      DOUBLE PRECISION omega(ngrid), xxx(ngrid)
      DOUBLE PRECISION delta, beta, op1, op2, on1, on2, aux
      DOUBLE PRECISION du
      DOUBLE PRECISION u, x
      DOUBLE PRECISION H1p,H2p,H1n,H2n
      DOUBLE PRECISION I1,I2

      du = op2 - op1

C     ---- H at +ω endpoints
      u = op1 + delta
      CALL XSHIFT(omega,xxx,ngrid,u,x)
      H1p = 1.0d0 * x

      u = op2 + delta
      CALL XSHIFT(omega,xxx,ngrid,u,x)
      H2p = 1.0d0 * x

C     ---- H at -ω endpoints
      u = on1 + delta
      CALL XSHIFT(omega,xxx,ngrid,u,x)
      H1n = 1.0d0 * x

      u = on2 + delta
      CALL XSHIFT(omega,xxx,ngrid,u,x)
      H2n = 1.0d0 * x

C     PV integrand values on positive ω endpoints
      I1 = (H1p - H1n) / op1
      I2 = (H2p - H2n) / op2

      aux = aux + 0.5d0 * du * (I2 + I1)

      RETURN
      END
C======================================================================
C======================================================================
C======================================================================
C======================================================================
      
C  ZBRENT_F77
C
C  Brent root finder for f(x)=0 on [A,B] with f(A)*f(B) <= 0.
C
C  INPUT:
C    F      external DOUBLE PRECISION FUNCTION F(x)
C    A,B    initial bracket endpoints
C    TOL    absolute tolerance for x (recommend: 1d-10 .. 1d-12)
C    ITMAX  maximum iterations (recommend: 100)
C
C  OUTPUT:
C    ROOT   estimated root
C    FROOT  f(ROOT)
C    IER    status:
C           0 = success
C           1 = input does not bracket a root
C           2 = did not converge in ITMAX iterations
C
C  Notes:
C   - Pure F77; no NaN handling. If your f() can overflow/NaN, guard inside f().
C   - Uses a mixed absolute/relative tolerance internally to avoid stalling.
C======================================================================
      SUBROUTINE ZBRENT_F77(F,A,B,TOL,ITMAX,ROOT,FROOT,IER)
      IMPLICIT NONE
      INTEGER ITMAX,IER,ITER
      DOUBLE PRECISION A,B,TOL,ROOT,FROOT
      DOUBLE PRECISION FA,FB,FC
      DOUBLE PRECISION C,D,E
      DOUBLE PRECISION P,Q,R,S
      DOUBLE PRECISION TOL1,XM
      DOUBLE PRECISION EPS
      DOUBLE PRECISION AA,BB,CC

      EXTERNAL F
      DOUBLE PRECISION F

      EPS = 2.2204460492503131D-16

      IER = 0
      AA  = A
      BB  = B
      FA  = F(AA)
      FB  = F(BB)

      IF (FA .EQ. 0.0D0) THEN
         ROOT = AA
         FROOT = FA
         RETURN
      ENDIF
      IF (FB .EQ. 0.0D0) THEN
         ROOT = BB
         FROOT = FB
         RETURN
      ENDIF

      IF (FA*FB .GT. 0.0D0) THEN
         IER = 1
         ROOT = AA
         FROOT = FA
         RETURN
      ENDIF

      CC = AA
      FC = FA
      D  = BB - AA
      E  = D

      DO 100 ITER=1,ITMAX

C        Ensure FB and FC have opposite signs (maintain bracket)
         IF (FB*FC .GT. 0.0D0) THEN
            CC = AA
            FC = FA
            D  = BB - AA
            E  = D
         ENDIF

C        Make |FB| <= |FC|
         IF (DABS(FC) .LT. DABS(FB)) THEN
            AA = BB
            BB = CC
            CC = AA
            FA = FB
            FB = FC
            FC = FA
         ENDIF

C        Convergence check
         TOL1 = 2.0D0*EPS*DABS(BB) + 0.5D0*TOL
         XM   = 0.5D0*(CC - BB)

         IF (DABS(XM) .LE. TOL1 .OR. FB .EQ. 0.0D0) THEN
            ROOT  = BB
            FROOT = FB
            RETURN
         ENDIF

C        Attempt interpolation
         IF (DABS(E) .GE. TOL1 .AND. DABS(FA) .GT. DABS(FB)) THEN
            S = FB/FA
            IF (AA .EQ. CC) THEN
C              Secant
               P = 2.0D0*XM*S
               Q = 1.0D0 - S
            ELSE
C              Inverse quadratic interpolation
               Q = FA/FC
               R = FB/FC
               P = S*(2.0D0*XM*Q*(Q-R) - (BB-AA)*(R-1.0D0))
               Q = (Q-1.0D0)*(R-1.0D0)*(S-1.0D0)
            ENDIF

            IF (P .GT. 0.0D0) Q = -Q
            P = DABS(P)

C           Accept interpolation only if it stays within bounds
            IF (2.0D0*P .LT. DMIN1(3.0D0*XM*Q - DABS(TOL1*Q),
     &                             DABS(E*Q))) THEN
               E = D
               D = P/Q
            ELSE
               D = XM
               E = XM
            ENDIF
         ELSE
C           Bisection fallback
            D = XM
            E = XM
         ENDIF

C        Next step
         AA = BB
         FA = FB
         IF (DABS(D) .GT. TOL1) THEN
            BB = BB + D
         ELSE
            BB = BB + DSIGN(TOL1, XM)
         ENDIF
         FB = F(BB)

 100  CONTINUE

      IER = 2
      ROOT = BB
      FROOT = FB
      RETURN
      END

C----- Brent variant reusing FA, FB from bracketing -----
      SUBROUTINE ZBRENT_F77_FAB(F,A,B,FA,FB,TOL,ITMAX,ROOT,FROOT,IER)
      IMPLICIT NONE
      INTEGER ITMAX,IER,ITER
      DOUBLE PRECISION A,B,FA,FB,TOL,ROOT,FROOT
      DOUBLE PRECISION FC
      DOUBLE PRECISION C,D,E
      DOUBLE PRECISION P,Q,R,S
      DOUBLE PRECISION TOL1,XM
      DOUBLE PRECISION EPS
      DOUBLE PRECISION AA,BB,CC

      EXTERNAL F
      DOUBLE PRECISION F

      EPS = 2.2204460492503131D-16

      IER = 0
      AA  = A
      BB  = B

      IF (FA .EQ. 0.0D0) THEN
         ROOT = AA
         FROOT = FA
         RETURN
      ENDIF
      IF (FB .EQ. 0.0D0) THEN
         ROOT = BB
         FROOT = FB
         RETURN
      ENDIF

      IF (FA*FB .GT. 0.0D0) THEN
         IER = 1
         ROOT = AA
         FROOT = FA
         RETURN
      ENDIF

      CC = AA
      FC = FA
      D  = BB - AA
      E  = D

      DO 100 ITER=1,ITMAX

C        Ensure FB and FC have opposite signs (maintain bracket)
         IF (FB*FC .GT. 0.0D0) THEN
            CC = AA
            FC = FA
            D  = BB - AA
            E  = D
         ENDIF

C        Make |FB| <= |FC|
         IF (DABS(FC) .LT. DABS(FB)) THEN
            AA = BB
            BB = CC
            CC = AA
            FA = FB
            FB = FC
            FC = FA
         ENDIF

C        Convergence check
         TOL1 = 2.0D0*EPS*DABS(BB) + 0.5D0*TOL
         XM   = 0.5D0*(CC - BB)

         IF (DABS(XM) .LE. TOL1 .OR. FB .EQ. 0.0D0) THEN
            ROOT  = BB
            FROOT = FB
            RETURN
         ENDIF

C        Attempt interpolation
         IF (DABS(E) .GE. TOL1 .AND. DABS(FA) .GT. DABS(FB)) THEN
            S = FB/FA
            IF (AA .EQ. CC) THEN
C              Secant
               P = 2.0D0*XM*S
               Q = 1.0D0 - S
            ELSE
C              Inverse quadratic interpolation
               Q = FA/FC
               R = FB/FC
               P = S*(2.0D0*XM*Q*(Q-R) - (BB-AA)*(R-1.0D0))
               Q = (Q-1.0D0)*(R-1.0D0)*(S-1.0D0)
            ENDIF

            IF (P .GT. 0.0D0) Q = -Q
            P = DABS(P)

C           Accept interpolation only if it stays within bounds
            IF (2.0D0*P .LT. DMIN1(3.0D0*XM*Q - DABS(TOL1*Q),
     &                             DABS(E*Q))) THEN
               E = D
               D = P/Q
            ELSE
               D = XM
               E = XM
            ENDIF
         ELSE
C           Bisection fallback
            D = XM
            E = XM
         ENDIF

C        Next step
         AA = BB
         FA = FB
         IF (DABS(D) .GT. TOL1) THEN
            BB = BB + D
         ELSE
            BB = BB + DSIGN(TOL1, XM)
         ENDIF
         FB = F(BB)

 100  CONTINUE

      IER = 2
      ROOT = BB
      FROOT = FB
      RETURN
      END


C======================================================================
C======================================================================
C======================================================================

C======================================================================
C  ZBRAC_EXPAND_F77
C
C  Attempts to find [A,B] such that f(A)*f(B) <= 0 by symmetric expansion
C  around X0.
C
C  INPUT:
C    F        external DOUBLE PRECISION FUNCTION F(x)
C    X0       center point (e.g. previous lambda)
C    SCALE    typical scale (e.g. bandwidth D, or max(|lambda|,1))
C    H0FAC    initial step as fraction of SCALE (e.g. 1d-3)
C    FAC      expansion factor per iteration (e.g. 1.6d0 or 2.0d0)
C    NTRY     max expansions (e.g. 50)
C    XMAXFAC  maximum |x-x0| allowed as multiple of SCALE (e.g. 20)
C
C  OUTPUT:
C    A,B      bracket endpoints
C    FA,FB    f(A), f(B)
C    IER      0 = bracket found
C             1 = failed to bracket in NTRY steps
C======================================================================
      SUBROUTINE ZBRAC_EXPAND_F77(F,X0,SCALE,H0FAC,FAC,NTRY,XMAXFAC,
     &                            A,B,FA,FB,IER)
      IMPLICIT NONE
      INTEGER :: NTRY,IER,IT
      DOUBLE PRECISION X0,SCALE,H0FAC,FAC,XMAXFAC
      DOUBLE PRECISION A,B,FA,FB,H,DXMAX
      EXTERNAL F
      DOUBLE PRECISION :: F

      IER = 0
      IF (SCALE .LE. 0.0D0) SCALE = 1.0D0

      DXMAX = XMAXFAC*SCALE
      H = H0FAC*SCALE
      IF (H .LE. 1.0D-14) H = 1.0D-14

      A = X0 - H
      B = X0 + H
      FA = F(A)
      FB = F(B)

      IF (FA .EQ. 0.0D0) THEN
         B = A
         FB = FA
         RETURN
      ENDIF
      IF (FB .EQ. 0.0D0) THEN
         A = B
         FA = FB
         RETURN
      ENDIF

      IF (FA*FB .LE. 0.0D0) RETURN

      DO 100 IT=1,NTRY
         H = H*FAC
         IF (H .GT. DXMAX) THEN
            IER = 1
            RETURN
         ENDIF

C        Expand both sides
         A = X0 - H
         B = X0 + H
         FA = F(A)
         FB = F(B)

         IF (FA .EQ. 0.0D0) THEN
            B = A
            FB = FA
            RETURN
         ENDIF
         IF (FB .EQ. 0.0D0) THEN
            A = B
            FA = FB
            RETURN
         ENDIF

         IF (FA*FB .LE. 0.0D0) RETURN
 100  CONTINUE

      IER = 1
      RETURN
      END
C=====================================================================
C=====================================================================
      SUBROUTINE PREP_WGT(beta, omega)
      IMPLICIT NONE
      INTEGER :: ngrid,N,nadd,naux,N1,N2,ngrid2
      INCLUDE 'PARAMETER'
      PARAMETER(naux=N+(N-1)*nadd,ngrid2=2*naux,ngrid=ngrid2+2*N1+2*N2)

      INTEGER j
      DOUBLE PRECISION beta
      DOUBLE PRECISION omega(ngrid)
      DOUBLE PRECISION wgt(ngrid)
      DOUBLE PRECISION ferm0
      EXTERNAL ferm0
      COMMON /wgtblk/ wgt

      DO j=1,ngrid
         wgt(j) = ferm0(beta*omega(j))
      END DO

      RETURN
      END



C======================================================================
C======================================================================
C======================================================================

C***************************************************************************
***************************************************************************
C***************************************************************************
!> @brief Updates the Lagrange multiplier rlambd0 using a root-finding method.
!>
!> This subroutine first calculates spectral functions (afm, afp, etc.)
!> based on the current value of rlambd0. It then uses this result as input
!> to an external function QBSTMNG, and finds the root of that function
!> to determine the new, updated value for rlambd0.
C***************************************************************************
      SUBROUTINE RLAMBDAPDT(rexp, sefp, sefm, sefr, sebp, sebm, sebr,
     &                    omega, beta, eps,
     &                   rlambd0_in, D_scale, rlambd0_out)
      IMPLICIT NONE

!     Precision definition
      INTEGER, PARAMETER :: dp = KIND(0.0D0)


!     Include file for grid parameters (Modern approach would use a MODULE)
      INTEGER   :: N,nadd,ne,N1,N2

      INCLUDE 'PARAMETER'
C      INTEGER ngrid, nadd, naux,N
C      INCLUDE 'PARAMETER'
C      PARAMETER (naux=N+(N-1)*nadd, ngrid=2*naux)

!     Parameters derived from the include file
      INTEGER, PARAMETER :: naux = N + (N - 1) * nadd
      INTEGER, PARAMETER :: ngrid2 = 2 * naux
      INTEGER, PARAMETER :: ngrid=ngrid2 + 2 * N1 + 2 * N2
C      INTEGER, PARAMETER :: ninter = nNeu + 4 * new
C      INTEGER, PARAMETER :: ngrid = ninter + 4 * ntemp
      INTEGER, PARAMETER :: nspin = 2

!     Input/Output Arguments
      REAL(dp), INTENT(IN) :: omega(ngrid),rexp(ngrid/2)
      REAL(dp), INTENT(IN) :: sefp(ngrid), sefm(ngrid), sefr(ngrid)
      REAL(dp), INTENT(IN) :: sebp(ngrid), sebm(ngrid), sebr(ngrid)
C      REAL(dp), INTENT(IN) :: seup(ngrid), seum(ngrid), seur(ngrid)
      REAL(dp), INTENT(IN)    :: beta, eps
      REAL(dp), INTENT(IN)    :: rlambd0_in   ! The initial guess for the parameter
      REAL(dp), INTENT(IN)    :: D_scale      ! A physical scale, e.g., bandwidth
      REAL(dp), INTENT(OUT)   :: rlambd0_out  ! The updated, final parameter

!     Local Arrays
      REAL(dp) :: abm(ngrid), abp(ngrid), afm(ngrid), afp(ngrid)
C      REAL(dp) :: aum(ngrid), aup(ngrid)
CC      REAL(dp) :: xxx(ngrid), omega0(ngrid)

!     Local Variables
      INTEGER  :: i, k, nhalf, IER, ITMAX, NTRY
      REAL(dp) :: den_f_i, den_b_i, den_u_i
      REAL(dp) :: den_f_k, den_b_k, den_u_k
      REAL(dp) :: A, B, FA, FB, ROOT, FROOT, TOL
      REAL(dp) :: X0, SCALE, H0FAC, FAC, XMAXFAC
      REAL(dp) :: AUXI

!     External function whose root we want to find.
!     FIXED: Correctly declare QBSTMNG as a function returning REAL(dp).
      REAL(dp) :: QBSTMNG
      EXTERNAL QBSTMNG

!     Common blocks for passing data to QBSTMNG (Modern approach would use a MODULE)
      COMMON /temp/ beta0
      REAL(dp) :: beta0
      COMMON /whtev/ omega0_common, xxx_common
      REAL(dp) :: omega0_common(ngrid), xxx_common(ngrid)
      COMMON /wgtblk/ wgt
      REAL(dp) :: wgt(ngrid)



! ---- Start of Executable Code ----


      nhalf = ngrid / 2
      beta0 = beta  ! Store beta in common block for QBSTMNG to access

! --- Loop 1: Calculate the spectral function arrays ('a' arrays) ---
      DO i = 1, nhalf
          k = i + nhalf

          ! Denominators for index i (first half)
          den_f_i = (omega(i) - eps + rlambd0_in - sefr(i))**2
     &      + sefp(i)**2
          den_b_i = (omega(i) + rlambd0_in - sebr(i))**2 + sebp(i)**2
C          den_u_i = (omega(i) - 2.0d0*eps - Urep + rlambd0_in
C     &     - seur(i))**2 + seup(i)**2

          afm(i) = sefm(i) / den_f_i
          abm(i) = sebm(i) / den_b_i
C          aum(i) = seum(i) / den_u_i

          ! Denominators for index k (second half)
          den_f_k = (omega(k) - eps + rlambd0_in-sefr(k))**2+sefp(k)**2
          den_b_k = (omega(k) + rlambd0_in - sebr(k))**2 + sebp(k)**2
C          den_u_k = (omega(k) - 2.0d0*eps - Urep + rlambd0_in
C     &     - seur(k))**2 + seup(k)**2

          afp(k) = sefp(k) / den_f_k
          abp(k) = sebp(k) / den_b_k
C          aup(k) = seup(k) / den_u_k

          ! Apply symmetry relations
          afp(i) = rexp(i) * afm(i)
          abp(i) = rexp(i) * abm(i)
C          aup(i) = rexp(i) * aum(i)

          afm(k) = rexp(nhalf - i + 1) * afp(k)
          abm(k) = rexp(nhalf - i + 1) * abp(k)
C           aum(k) = rexp(nhalf - i + 1) * aup(k)
       END DO

! --- Combine arrays using modern array syntax and store in COMMON blocks ---
      omega0_common = omega
C      xxx_common    = nspin * (afm + afp) + abm + abp + aum + aup
      xxx_common    = nspin * (afm + afp) + abm + abp
      CALL PREP_WGT(beta0, omega0_common)

! --- Find the root of QBSTMNG to get the updated rlambd0 ---

      ! FIXED: Use the input argument `rlambd0_in` as the initial center.
      X0 = rlambd0_in
      
      ! FIXED: Use the input argument `D_scale` for the physical scale.
      SCALE = D_scale

      ! Parameters for the bracketing routine
      H0FAC   = 1.0D-3
      FAC     = 1.8D0
      NTRY    = 24
      XMAXFAC = 50.0D0
C --- Bracketing control parameters ---
C H0FAC   : Initial step-size factor (relative to problem scale); sets
C            the starting search interval around the initial guess.
C FAC     : Geometric expansion factor for step size if no sign change
C            is found (h <- FAC*h each iteration).
C NTRY    : Maximum number of bracketing attempts (expansions).
C XMAXFAC : Maximum allowed search range (relative to scale) to prevent
C     excessive excursions from the initial guess.
      



C      CALL ZBRAC_EXPAND_F77(QBSTMNG, X0, SCALE, H0FAC, FAC, NTRY,    &
C     &                      XMAXFAC, A, B, FA, FB, IER)
         CALL ZBRAC_EXPAND_F77(QBSTMNG, X0, SCALE, H0FAC, FAC, NTRY,
     &  XMAXFAC, A, B, FA, FB, IER)
      IF (IER .NE. 0) THEN
         PRINT*, 'Bracketing failed in ZBRAC_EXPAND_F77'
         STOP
      ENDIF



      ! Parameters for the root solver
      TOL   = 1.0D-7
      ITMAX = 100

      CALL ZBRENT_F77_FAB(QBSTMNG, A, B, FA, FB, TOL, ITMAX,
     &                   ROOT, FROOT, IER)
      IF (IER .NE. 0) THEN
         PRINT*, 'ZBRENT_F77 failed, IER=', IER, ' f(root)=', FROOT
         STOP
      ENDIF

      ! FIXED: Assign the final result to the output argument.
      rlambd0_out = ROOT+ rlambd0_in



      RETURN
      END SUBROUTINE RLAMBDAPDT


C======================================================================
C======================================================================
C======================================================================

C Argument roles (by position and intent) in ZBRAC_EXPAND_F77
C Inputs (read-only)
C
C These control how the bracketing is attempted:
C
C QBSTMNG
C External function whose root is sought.
C
C X0
C Initial guess for the root.
C
C SCALE
C Characteristic scale for the search.
C
C H0FAC
C Initial step-size factor.
C
C FAC
C Step expansion/damping factor.
C
C NTRY
C Maximum number of expansion attempts.
C
C XMAXFAC
C Maximum allowed extrapolation factor.
C
C These are inputs only.
C
C Outputs / In-Out arguments
C
C These are the results of the bracketing procedure:
C
C A, B
C Output (or in/out):
C On return, these are the bracketing interval endpoints such that:
C
C f(A) * f(B) ≤ 0
C
C
C (i.e., the root is bracketed).
C
C FA, FB
C Output (or in/out):
C Function values at the bracket endpoints:
C
C FA = QBSTMNG(A)
C FB = QBSTMNG(B)
C
C
C IER
C Output (status code):
C
C IER = 0 → success, bracket found
C
C IER ≠ 0 → failure (e.g. exceeded NTRY, invalid function values, etc.)
C
C These must be treated as outputs by the caller.

C%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
