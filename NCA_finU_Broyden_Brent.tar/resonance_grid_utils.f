
C=======================================================================
C  resonance_grid_utils.f
C
C  Utilities to augment a symmetric nonzero grid produced e.g. by
C  GRID + RENORM.
C
C  Starting from a sorted, symmetric grid omega_in(1:ngrid_in),
C  the routine BUILD_RESONANCE_GRID:
C
C    1) keeps all original nonzero points
C    2) adds n1 extra positive points around eps1 with width sigma1
C    3) adds n2 extra positive points around eps2 with width sigma2
C    4) mirrors all added points to the negative side
C    5) sorts and removes duplicates
C    6) if duplicates/overlap reduced the total size, fills missing
C       symmetric pairs by bisecting the widest negative-side gaps
C
C  The final grid:
C    - is symmetric
C    - contains no omega = 0 point
C    - contains no coinciding points within tolerance
C    - has exactly ngrid_target = ngrid_in + 2*n1 + 2*n2 points
C      provided MAXOUT is chosen large enough
C
C=======================================================================

      SUBROUTINE BUILD_RESONANCE_GRID(omega_in,ngrid_in,D,
     &     eps1,sigma1,n1,eps2,sigma2,n2,
     &     omega_out,ngrid_out,maxout)

      IMPLICIT NONE

      INTEGER ngrid_in,ngrid_out,n1,n2,maxout
      INTEGER ngrid_target
      DOUBLE PRECISION D,eps1,sigma1,eps2,sigma2
      DOUBLE PRECISION omega_in(ngrid_in),omega_out(maxout)

      ngrid_target = ngrid_in + 2*n1 + 2*n2

      CALL ADD_RESONANCE_GRID(omega_in,ngrid_in,D,
     &     eps1,sigma1,n1,eps2,sigma2,n2,
     &     omega_out,ngrid_out,maxout)

      IF (ngrid_out .LT. ngrid_target) THEN
         CALL FILL_TO_TARGET_WIDEST(omega_out,ngrid_out,
     &        ngrid_target,maxout)
      ENDIF

      RETURN
      END


      SUBROUTINE ADD_RESONANCE_GRID(omega,ngrid_in,D,
     &     eps1,sigma1,n1,eps2,sigma2,n2,
     &     omega_out,ngrid_out,maxout)

      IMPLICIT NONE

      INTEGER ngrid_in,ngrid_out,n1,n2,maxout
      INTEGER i,m,muniq
      DOUBLE PRECISION D,eps1,eps2,sigma1,sigma2
      DOUBLE PRECISION omega(ngrid_in),omega_out(maxout)
      DOUBLE PRECISION work(maxout)
      DOUBLE PRECISION tol

      tol = 1.0D-12*DMAX1(1.0D0,D)

C----- Start from original grid, but exclude omega = 0
      m = 0
      DO 10 i=1,ngrid_in
         IF (DABS(omega(i)) .GT. tol) THEN
            m = m + 1
            IF (m .GT. maxout) THEN
               PRINT *, 'ADD_RESONANCE_GRID: MAXOUT too small'
               STOP
            ENDIF
            work(m) = omega(i)
         ENDIF
 10   CONTINUE

C----- Add local symmetric points around eps1
      CALL ADD_ONE_WINDOW(eps1,sigma1,n1,D,tol,work,m,maxout)

C----- Add local symmetric points around eps2
      CALL ADD_ONE_WINDOW(eps2,sigma2,n2,D,tol,work,m,maxout)

C----- Sort
      CALL SORT_ASCENDING(work,m)

C----- Remove duplicates and any accidental zero
      muniq = 0
      DO 20 i=1,m
         IF (DABS(work(i)) .LE. tol) GOTO 20
         IF (muniq .EQ. 0) THEN
            muniq = 1
            omega_out(muniq) = work(i)
         ELSE
            IF (DABS(work(i)-omega_out(muniq)) .GT. tol) THEN
               muniq = muniq + 1
               omega_out(muniq) = work(i)
            ENDIF
         ENDIF
 20   CONTINUE

      ngrid_out = muniq

      RETURN
      END


      SUBROUTINE ADD_ONE_WINDOW(eps,sigma,n,D,tol,work,m,maxout)

      IMPLICIT NONE

      INTEGER n,m,maxout
      INTEGER k
      DOUBLE PRECISION eps,sigma,D,tol
      DOUBLE PRECISION work(maxout)
      DOUBLE PRECISION pi,umax,u,x,window_factor

      pi = 4.0D0*DATAN(1.0D0)

      IF (n .LE. 0) RETURN

      IF (eps .LE. 0.0D0) THEN
         PRINT *, 'ADD_ONE_WINDOW: eps must be > 0'
         STOP
      ENDIF

      IF (sigma .LE. 0.0D0) THEN
         PRINT *, 'ADD_ONE_WINDOW: sigma must be > 0'
         STOP
      ENDIF

C----- Use a +- window_factor*sigma window around eps
      window_factor = 5.0D0
      umax = DATAN(window_factor)

C----- If only one point requested, place it exactly at eps
      IF (n .EQ. 1) THEN
         x = eps
         CALL ADD_SYM_POINT(x,D,tol,work,m,maxout)
         RETURN
      ENDIF

C----- Tangent mesh clustered around eps
      DO 10 k=1,n
         u = -umax + (2.0D0*umax)*DFLOAT(k-1)/DFLOAT(n-1)
         x = eps + sigma*DTAN(u)
         CALL ADD_SYM_POINT(x,D,tol,work,m,maxout)
 10   CONTINUE

      RETURN
      END


      SUBROUTINE ADD_SYM_POINT(x,D,tol,work,m,maxout)

      IMPLICIT NONE

      INTEGER m,maxout
      DOUBLE PRECISION x,D,tol
      DOUBLE PRECISION work(maxout)
      DOUBLE PRECISION xp

      xp = DABS(x)

C----- Reject zero and points outside the band
      IF (xp .LE. tol) RETURN
      IF (xp .GE. D - tol) RETURN

      IF (m + 2 .GT. maxout) THEN
         PRINT *, 'ADD_SYM_POINT: MAXOUT too small'
         STOP
      ENDIF

      m = m + 1
      work(m) = -xp
      m = m + 1
      work(m) =  xp

      RETURN
      END


      SUBROUTINE FILL_TO_TARGET_WIDEST(omega,ngrid2,ngrid_target,
     &     maxout)

      IMPLICIT NONE

      INTEGER ngrid2,ngrid_target,maxout
      INTEGER i,j,deficit,npairs,ibest
      DOUBLE PRECISION omega(maxout)
      DOUBLE PRECISION gap,gapbest,xleft,xright,tol

      tol = 1.0D-12

      IF (ngrid_target .LT. ngrid2) THEN
         PRINT *, 'FILL_TO_TARGET_WIDEST: target smaller than current'
         STOP
      ENDIF

      deficit = ngrid_target - ngrid2

      IF (deficit .EQ. 0) RETURN

      IF (MOD(deficit,2) .NE. 0) THEN
         PRINT *, 'FILL_TO_TARGET_WIDEST: deficit must be even'
         STOP
      ENDIF

      npairs = deficit/2

      DO 30 i=1,npairs

         gapbest = -1.0D0
         ibest   = -1

C-------- Search widest gap on negative side only
         DO 10 j=1,ngrid2/2-1
            gap = omega(j+1) - omega(j)
            IF (gap .GT. gapbest) THEN
               gapbest = gap
               ibest = j
            ENDIF
 10      CONTINUE

         IF (ibest .LT. 1) THEN
            PRINT *, 'FILL_TO_TARGET_WIDEST: no valid interval found'
            STOP
         ENDIF

         xleft  = 0.5D0*(omega(ibest) + omega(ibest+1))
         xright = -xleft

         IF (DABS(xleft) .LE. tol .OR. DABS(xright) .LE. tol) THEN
            PRINT *, 'FILL_TO_TARGET_WIDEST: midpoint too close to zero'
            STOP
         ENDIF

         IF (ngrid2 + 2 .GT. maxout) THEN
            PRINT *, 'FILL_TO_TARGET_WIDEST: MAXOUT too small'
            STOP
         ENDIF

         ngrid2 = ngrid2 + 1
         omega(ngrid2) = xleft
         ngrid2 = ngrid2 + 1
         omega(ngrid2) = xright

         CALL SORT_ASCENDING(omega,ngrid2)

 30   CONTINUE

      RETURN
      END


      SUBROUTINE SORT_ASCENDING(a,n)

      IMPLICIT NONE

      INTEGER n
      INTEGER i,j
      DOUBLE PRECISION a(n),tmp

      DO 20 i=2,n
         tmp = a(i)
         j = i - 1
 10      CONTINUE
         IF (j .GE. 1) THEN
            IF (a(j) .GT. tmp) THEN
               a(j+1) = a(j)
               j = j - 1
               GOTO 10
            ENDIF
         ENDIF
         a(j+1) = tmp
 20   CONTINUE

      RETURN
      END


C=======================================================================
C  Example calling sequence:
C
C      INTEGER NGRID, NGRID2, MAXOUT
C      PARAMETER (MAXOUT=200000)
C      DOUBLE PRECISION D, EPS1, EPS2, SIGMA1, SIGMA2
C      INTEGER N1, N2
C      DOUBLE PRECISION FREQ(50000), FREQ2(MAXOUT)
C
C      CALL GRID(GAMMA,N,NADD,NAUX,NGRID,FREQ)
C      CALL RENORM(D,NGRID,FREQ)
C
C      EPS1   = ...
C      SIGMA1 = ...
C      N1     = ...
C      EPS2   = ...
C      SIGMA2 = ...
C      N2     = ...
C
C      CALL BUILD_RESONANCE_GRID(FREQ,NGRID,D,
C     &     EPS1,SIGMA1,N1,EPS2,SIGMA2,N2,
C     &     FREQ2,NGRID2,MAXOUT)
C
C  On return:
C      FREQ2(1:NGRID2) is sorted, symmetric, has no omega=0,
C      has no duplicates within tolerance, and has exactly
C      NGRID2 = NGRID + 2*N1 + 2*N2.
C=======================================================================
