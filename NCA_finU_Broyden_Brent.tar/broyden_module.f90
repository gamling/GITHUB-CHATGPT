!> Broyden mixing (Fortran 90+), following PRB 80, 125125 (2009), Eqs. (19)-(25)
!> - Robust against near-zero history differences (avoids divide-by-zero / NaNs)
!> - Avoids explicit matrix inversion (uses LU + triangular solves)
!> - Returns INFO instead of STOP
!
!  Required external libs: BLAS + LAPACK (DGEMV, DGETRF, DGETRS)
!
!  Calling convention (recommended):
!     call broyden(m, n, mmax, Fmatrix, Vmatrix, Vout, info)            ! uses default alpha=0.2, w0=0.01
!     call broyden(m, n, mmax, Fmatrix, Vmatrix, Vout, info, alpha=..., w0=...)
!
module broyden_mixing
  use, intrinsic :: iso_fortran_env, only : real64
  implicit none
  private
  public :: broyden


  interface
  subroutine dgetrf(m, n, a, lda, ipiv, info)
    integer, intent(in)    :: m, n, lda
    integer, intent(out)   :: ipiv(*)
    integer, intent(out)   :: info
    double precision, intent(inout) :: a(lda, *)
  end subroutine dgetrf

  subroutine dgetrs(trans, n, nrhs, a, lda, ipiv, b, ldb, info)
    character(len=1), intent(in) :: trans
    integer, intent(in)    :: n, nrhs, lda, ldb
    integer, intent(in)    :: ipiv(*)
    integer, intent(out)   :: info
    double precision, intent(in)    :: a(lda, *)
    double precision, intent(inout) :: b(ldb, *)
  end subroutine dgetrs

  subroutine dgemv(trans, m, n, alpha, a, lda, x, incx, beta, y, incy)
    character(len=1), intent(in) :: trans
    integer, intent(in) :: m, n, lda, incx, incy
    double precision, intent(in) :: alpha, beta
    double precision, intent(in) :: a(lda, *)
    double precision, intent(in) :: x(*)
    double precision, intent(inout) :: y(*)
  end subroutine dgemv
end interface


contains

  subroutine broyden(m, n, mmax, Fmatrix, Vmatrix, Vout, info, alpha, w0)
    ! Inputs
    integer, intent(in) :: m, n, mmax
    real(real64), intent(in) :: Fmatrix(mmax, n), Vmatrix(mmax, n)

    ! Outputs
    real(real64), intent(out) :: Vout(n)
    integer, intent(out) :: info

    ! Optional parameters
    real(real64), intent(in), optional :: alpha, w0

    ! Locals
    integer :: i, j, k, mminusone
    real(real64) :: alpha_loc, w0_loc
    real(real64) :: auxA, df, dv
    real(real64) :: fnorm, tol_row

    ! Workspace (allocated to actual need)
    real(real64), allocatable :: DeltaF(:,:), DeltaV(:,:), YOU(:,:)
    real(real64), allocatable :: C(:), weight(:), work(:)
    real(real64), allocatable :: A(:,:), rhs(:), q(:), scrvec(:)
    integer, allocatable :: ipiv(:)

    ! Defaults (match your original v3.f)
    alpha_loc = 0.2_real64
    w0_loc    = 0.01_real64
    if (present(alpha)) alpha_loc = alpha
    if (present(w0))    w0_loc    = w0

    ! Validate basic arguments
    info = 0
    if (n <= 0 .or. mmax <= 0 .or. m <= 0) then
      info = -1
      Vout = 0.0_real64
      return
    end if
    if (m > mmax) then
      info = -2
      Vout = 0.0_real64
      return
    end if

    mminusone = m - 1

    ! If no history, fall back to simple mixing: Vout = V(m) + alpha * F(m)
    if (mminusone <= 0) then
      do k = 1, n
        Vout(k) = Vmatrix(m, k) + alpha_loc * Fmatrix(m, k)
      end do
      info = 0
      return
    end if

    ! Allocate
    allocate(DeltaF(mminusone, n), DeltaV(mminusone, n), YOU(mminusone, n), stat=info)
    if (info /= 0) then
      info = -100
      Vout = 0.0_real64
      return
    end if

    allocate(C(mminusone), weight(mminusone), work(mminusone), stat=info)
    if (info /= 0) then
      info = -101
      Vout = 0.0_real64
      return
    end if

    allocate(A(mminusone, mminusone), ipiv(mminusone), rhs(mminusone), q(mminusone), scrvec(n), stat=info)
    if (info /= 0) then
      info = -102
      Vout = 0.0_real64
      return
    end if

    ! Initialize weights (you can replace with your own scheme later)
    weight = 1.0_real64

    ! Norm scale for robust row-thresholding
    fnorm = 0.0_real64
    do k = 1, n
      fnorm = fnorm + Fmatrix(m, k) * Fmatrix(m, k)
    end do
    fnorm = sqrt(fnorm)
    ! Row tolerance: scale with current residual norm; conservative and dimensionally consistent
    tol_row = max(1.0_real64, fnorm) * sqrt(epsilon(1.0_real64))

    ! Build DeltaF/DeltaV and row norms
    do i = 1, mminusone
      work(i) = 0.0_real64
      do k = 1, n
        df = Fmatrix(i+1, k) - Fmatrix(i, k)
        dv = Vmatrix(i+1, k) - Vmatrix(i, k)
        DeltaF(i, k) = df
        DeltaV(i, k) = dv
        work(i) = work(i) + df*df
      end do
      work(i) = sqrt(work(i))
    end do

    ! Normalize rows; safely handle near-zero rows by deactivating them (weight=0)
    do i = 1, mminusone
      if (work(i) <= tol_row) then
        ! Degenerate / stagnant history step: remove its influence cleanly
        weight(i) = 0.0_real64
        DeltaF(i, :) = 0.0_real64
        DeltaV(i, :) = 0.0_real64
        YOU(i, :)    = 0.0_real64
      else
        do k = 1, n
          DeltaF(i, k) = DeltaF(i, k) / work(i)
          DeltaV(i, k) = DeltaV(i, k) / work(i)
          YOU(i, k)    = alpha_loc * DeltaF(i, k) + DeltaV(i, k)  ! Eq. (23)
        end do
      end if
    end do

    ! C(i) = sum_k DeltaF(i,k) * F(m,k)  (Eq. 22)
    do i = 1, mminusone
      auxA = 0.0_real64
      do k = 1, n
        auxA = auxA + DeltaF(i, k) * Fmatrix(m, k)
      end do
      C(i) = auxA
    end do

    ! Build A (Eqs. 24-25):
    ! A(i,j) = w0^2 * delta_ij + weight(i)*weight(j) * sum_k DeltaF(i,k)*DeltaF(j,k)
    do i = 1, mminusone
      do j = 1, mminusone
        auxA = 0.0_real64
        do k = 1, n
          auxA = auxA + DeltaF(i, k) * DeltaF(j, k)
        end do
        A(i, j) = weight(i) * weight(j) * auxA
        if (i == j) A(i, j) = A(i, j) + w0_loc*w0_loc
      end do
    end do

    ! We need scrvec = YOU^T * (weight * p), where p solves A^T p = (weight * C)
    ! Avoid explicit inverse via LU + solve.

    ! rhs = weight * C
    do i = 1, mminusone
      rhs(i) = weight(i) * C(i)
    end do

    ! LU factorization of A
    call dgetrf(mminusone, mminusone, A, mminusone, ipiv, info)
    if (info /= 0) then
      ! info > 0 means U(info,info) is exactly zero => singular
      ! Recommend caller fall back to simple mixing for this iteration.
      return
    end if

    ! Solve A^T * p = rhs  (rhs overwritten with p)
    call dgetrs('T', mminusone, 1, A, mminusone, ipiv, rhs, mminusone, info)
    if (info /= 0) then
      return
    end if

    ! q = weight * p
    do i = 1, mminusone
      q(i) = weight(i) * rhs(i)
    end do

    ! scrvec = YOU^T * q  (size n)
    scrvec = 0.0_real64
    call dgemv('T', mminusone, n, 1.0_real64, YOU, mminusone, q, 1, 0.0_real64, scrvec, 1)

    ! Final update: Vout = V(m,:) + alpha * F(m,:) - scrvec
    do k = 1, n
      Vout(k) = Vmatrix(m, k) + alpha_loc * Fmatrix(m, k) - scrvec(k)
    end do

    info = 0
  end subroutine broyden

end module broyden_mixing
