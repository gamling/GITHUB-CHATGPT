
      SUBROUTINE OWNBUBBLE(omegf,af,au,ad)
C      SUBROUTINE OWNBUBBLE(omegf,nf,omegu,nu,af,au,ad)
C      IMPLICIT DOUBLE PRECISION (A-H,O-Z) 
      
      INTEGER N,nadd,naux,ngrid
      INCLUDE 'PARAMETER' 
      PARAMETER (naux=N+(N-1)*nadd,ngrid=2*naux)
      INTEGER nf,nu,nca,i,l,k,j
      DOUBLE PRECISION pi,peak,dummy
      PARAMETER(pi=3.1415926535898d0)
      DOUBLE PRECISION omegf0(ngrid)
      DOUBLE PRECISION omegf(ngrid),omegu(ngrid),af(ngrid),au(ngrid)
      DOUBLE PRECISION aun(ngrid+ngrid,ngrid),afn(ngrid+ngrid,ngrid)
      DOUBLE PRECISION omegfa(ngrid+ngrid,ngrid),ad(ngrid)
      DOUBLE PRECISION omegfv(ngrid+ngrid,ngrid),aux(ngrid+ngrid)
      DOUBLE PRECISION aux2(ngrid+ngrid)
      DOUBLE PRECISION aux3(ngrid+ngrid)
      INTEGER indx(ngrid+ngrid),inaux(ngrid+ngrid)
      INTEGER index(ngrid+ngrid,ngrid),izeiger(2)
      DOUBLE PRECISION help(2),depsilon(ngrid+ngrid,ngrid)
      
      

      nu=ngrid
      nf=ngrid
      nca=2*nf
      DO i=1,nf
         omegu(i)=omegf(i)
      END DO

         
      do 1111 l=1,nf            !all the omegas
         peak=omegf(l)
         do k=1,nu
            omegfv(k,l)=omegu(k)+peak 
         end do                 
    

         do i=1,nu              !indx is an index field
            indx(i)=i
            aux(i)=omegfv(i,l)            
         end do

c!==================================!dummy is flag for second grid
         dummy=-666666.0d0
         do i=1,nf
            aux2(i+nu)=dummy
            aux3(i+nu)=af(i)
         end do
c!==================================
         do i=1,nu
            aux2(i)=au(i)
            aux3(i)=dummy
         end do
         do i=1,nf
            indx(i+nu)=i+nu
            aux(i+nu)=omegf(i)
         end do

c----------------------------
         call ownsort(nca,nu,aux,indx) !sort the frequencies
c----------------------------
         do k=1,nca
            inaux(k)=indx(k)
         end do
         
         do i=1,nca-1
            if ((aux(i+1)-aux(i)).LT.1.0d-9) then
               if(i.eq.(nca-1)) then
                  aux(i+1)=2.0d0*aux(i)-aux(i-1)
               else
                  aux(i+1)=0.5d0*(aux(i)+aux(i+2))
                  
                  if(indx(i+1).lt.indx(i)) then !indx(i+1) from omegu
                     numbre=indx(i+1) !indx for interpol of omegu
                     indx(i+1)=indx(i)
                     indx(i)=numbre
                  else
                     numbre=inaux(i+1)
                     inaux(i+1)=inaux(i)
                     inaux(i)=numbre
                  endif
                  
               end if
            endif
         end do
         
         
         do i=1,nca
            index(i,l)=indx(i)  !store index table
         end do
         do i=1,nca
            omegfa(i,l)=aux(i)  !store frequency vectors
         end do
         
c-----------------------
         do i=1,nca             !sorting while copying
            aun(i,l)=aux2(indx(i))
            afn(i,l)=aux3(inaux(i))
         end do
*----------------------------
c!        loop over ordered vector; picks out dummy fields and interpolates
         help(1)=0.0d0
         izeiger(1)=0
         izaehler=0
         do i=1,nca
            IF (aun(i,l).NE.dummy) THEN
               izaehler=izaehler+1
               help(2)=aun(i,l)
               izeiger(2)=i
               IF (izeiger(1).NE.(i-1)) THEN
                  number=i-izeiger(1)-1
                  nnn=izeiger(1)
                  DO k=1,number
                     kkk=nnn+k
                     if(nnn.eq.0) then
                        aun(kkk,l)=0.0d0
                     else
                        xx1=aun(i,l)-aun(nnn,l)
                        aaa=(omegfa(kkk,l)-omegfa(nnn,l))/
     &                       (omegfa(i,l)-omegfa(nnn,l))
                        aun(kkk,l)=aun(nnn,l)+xx1*aaa
                     endif
                  END DO
               END IF
               IF (izaehler.EQ.nu) THEN
                  DO kkk=i+1,nca
                     aun(kkk,l)=0.0d0
                  END DO
                  GOTO 111
               END IF
               help(1)=help(2)
               izeiger(1)=izeiger(2)
            END IF
         END DO
         
 111     CONTINUE
         
         
*----------------------------
c!        loop over ordered vector; picks out dummy fields and interpolates
         help(1)=0.0d0
         izeiger(1)=0
         izaehler=0
         do i=1,nca
            IF (afn(i,l).NE.dummy) THEN
               izaehler=izaehler+1
               help(2)=afn(i,l)
               izeiger(2)=i
               IF (izeiger(1).NE.(i-1)) THEN
                  number=i-izeiger(1)-1
                  nnn=izeiger(1)
                  DO k=1,number
                     kkk=nnn+k
                     if(nnn.eq.0) then
                        afn(kkk,l)=0.0d0
                     else
                        xx1=afn(i,l)-afn(nnn,l)
                        aaa=(omegfa(kkk,l)-omegfa(nnn,l))/
     &                       (omegfa(i,l)-omegfa(nnn,l))
                        afn(kkk,l)=afn(nnn,l)+xx1*aaa
                     endif
                  END DO
               END IF
               IF (izaehler.EQ.nf) THEN
                  DO kkk=i+1,nca
                     afn(kkk,l)=0.0d0
                  END DO
                  GOTO 222
               END IF
               help(1)=help(2)
               izeiger(1)=izeiger(2)
            END IF
         END DO
         
 222     CONTINUE
         
c------------------------
         DO i=1,nca
            if (i.eq.1) then
               depsilon(i,l)=(omegfa(2,l)-omegfa(1,l))/2.0d0
            else if (i.eq.nca) then
               depsilon(i,l)=(omegfa(nca,l)-omegfa(nca-1,l))/2.0d0
            else
               depsilon(i,l)=(omegfa(i+1,l)-omegfa(i-1,l))/2.0d0
            endif
         END DO
c-----------------------------
         ad(l)=0.0d0
         DO i=1,nca
            ad(l)=ad(l)+aun(i,l)*afn(i,l)*depsilon(i,l)
         END DO
         ad(l)=ad(l)/pi
 1111 CONTINUE
      
      RETURN
      END
      
************************************************************************
************************************************************************
      subroutine ownsort(nges,n1,w,indx)
      implicit integer (i,j,k,l,m,n)
      implicit real*8 (a-h,o-z)
      dimension w(nges),aux(nges),indx(nges)
      
      
      n2=nges-n1
      l=1
      k=n1+1
      do i=1,nges
         mem=i
         if(w(l).lt.w(k)) then
            indx(i)=l
            aux(i)=w(l)
            if(l.eq.n1) then
               goto 30
            end if
            l=l+1
         else
            indx(i)=k
            aux(i)=w(k)
            if(k.eq.nges) then
               goto 40
            end if
            k=k+1
         end if
      end do

 30   continue
      do i=k,nges
         aux(i)=w(i)
         indx(i)=i
      end do
      goto 50
 40   continue
      do i=l,n1
         aux(i+n2)=w(i)
         indx(i+n2)=i
      end do

 50   continue
      do i=1,nges
         w(i)=aux(i)
      end do
      return
      end
************************************************************************
************************************************************************
*********************CALCULATES PARTICLE NUMBERS************************
      SUBROUTINE PN(exom,beta,n,omega,field,nf)
      IMPLICIT NONE
      INTEGER i,j,n,m,iscr(n),kk,k,l
      DOUBLE PRECISION exom,nf,beta,field(n),omega(n)
      DOUBLE PRECISION wert1,wert2,wertn,freq1,freq2
      DOUBLE PRECISION omex,aux
      DOUBLE PRECISION ferm0,pi
      PARAMETER(pi=3.1415926535898d0)
      EXTERNAL ferm0
         DO j=1,n
            omex=exom+omega(j)  !frequency argument of abm
            CALL locate(omega,n,omex,m)
            iscr(j)=m           !index of epsilon on eps+exom
         END DO
         aux=0.0d0
         m=iscr(1)
         IF(m.EQ.0) THEN
            wert1=0.0d0
         ELSEIF(m.EQ.n) THEN
            wert1=0.0d0
         ELSE
            wert1=field(m)+(field(m+1)-field(m))/(omega(m+1)-omega(m))
     &           *(omega(1)+exom-omega(m)) !interpolate A_b
         ENDIF
         DO j=1,n-1             !integration loop
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCpositive freq
                                !if iscr(j)=iscr(j+1),no add. points
            l=iscr(j+1)
            m=iscr(j)
            kk=l-m
            IF(l.EQ.0) THEN
               wert2=0.0d0
            ELSEIF(l.EQ.n) THEN
               wert2=0.0d0
            ELSE
               wert2=field(l)+(field(l+1)-field(l))/(omega(l+1)-omega(l)
     &              )*(omega(j+1)+exom-omega(l)) !interpolate A_b
            ENDIF
            IF(kk.eq.0) THEN
               aux=aux+0.5*(omega(j+1)-omega(j))*
     &              (ferm0(beta*omega(j+1))*wert2+
     &              ferm0(beta*omega(j))*wert1)
c     write(86,*) omega(j),wert2
            ELSE
c               IF((m.eq.0).OR.(m.eq.n)) GOTO 30
               freq1=omega(j)
               DO k=1,kk
c     write(86,*) omega(m+k)-exom,abm(m+k)
                  freq2=omega(m+k)-exom
                  wertn=field(m+k)
                  aux=aux+0.5d0*(freq2-freq1)*
     &                 (ferm0(beta*freq2)*wertn+
     &                 ferm0(beta*freq1)*wert1)
                  freq1=freq2
                  wert1=wertn
               END DO
               aux=aux+0.5*(omega(j+1)-freq1)* !add last interval
     &              (ferm0(beta*omega(j+1))*wert2+
     &              ferm0(beta*freq1)*wert1)
            ENDIF
 30         CONTINUE
            wert1=wert2
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCpositive freq
         END DO
         nf=aux/pi
      RETURN
      END
