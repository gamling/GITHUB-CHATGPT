***********************************************************************
***********************************************************************
      SUBROUTINE GRID(Gamma,gam_arr,N,Nadd,naux,ngrid,gridvec)
      IMPLICIT NONE
      INTEGER N,Nadd,ngrid,naux
      INTEGER i,j
      DOUBLE PRECISION D,GAMMA
      DOUBLE PRECISION aux,delta,VECTOR(1:naux)
      DOUBLE PRECISION gam_arr(N) !contains GAMMA**(-i)
      DOUBLE PRECISION gridvec(1:ngrid)

      DO i=1,naux
      vector(i)=0.0d0
      END DO
      
      aux=Gamma**(-N+1)
      DO i=1,N
         IF(i.ne.N) THEN
            DO j=0,Nadd
               delta=aux*(Gamma-1.0)/DFLOAT(Nadd+1)
               IF(j.eq.0) THEN
                  vector((i-1)*(Nadd+1)+1)=aux
               ELSE
                  vector((i-1)*(Nadd+1)+1+j)=
     &              vector((i-1)*(Nadd+1)+j)+delta
               ENDIF
            END DO
            aux=aux*Gamma
         ELSE
            vector(naux)=aux
         END IF
      END DO
      
      DO i=1,naux
         gridvec(i)=-vector(naux+1-i)
         gridvec(i+naux)=vector(i)
      END DO

      aux=1.0d0
      DO i=1,N
         aux=aux*Gamma
         gam_arr(i)=aux
      END DO

      END
***********************************************************************
***********************************************************************
      SUBROUTINE RENORM(D,ngrid,freq)
      IMPLICIT NONE
      INTEGER ngrid
      INTEGER i
      DOUBLE PRECISION D,freq(1:ngrid)

      DO i=1,ngrid
         freq(i)=D*freq(i)
      END DO
      END
***********************************************************************
***********************************************************************
      DOUBLE PRECISION FUNCTION cspec(xxx)
      IMPLICIT NONE
      INTEGER nxxx,j0
      DOUBLE PRECISION pi,bandwidth,dx,xxx
      parameter (pi=3.1415926535898d0) 
      parameter (nxxx=8000)
      DOUBLE PRECISION dos(nxxx),xw(nxxx)
      
      COMMON /doskram/ dos,xw,bandwidth
      
      
      dx=bandwidth/dfloat(nxxx)
      
      IF(xxx.LE.(-bandwidth/2.0+1.5*dx)) THEN
         cspec=0.0
         
      ELSEIF(xxx.GE.bandwidth/2.0-dx) THEN
         cspec=0.0
         
      ELSE
         j0=int((xxx+bandwidth/2.0)/dx)
         cspec=(dos(j0+1)-dos(j0))/dx*(xxx-xw(j0))+dos(j0)
      ENDIF      
      RETURN
      END
***********************************************************************
***********************************************************************
      SUBROUTINE DOSINTERPOL
      IMPLICIT NONE
      INTEGER nxxx,i
      PARAMETER (nxxx=8000)
      DOUBLE PRECISION pi,bandwidth,dx,dosnull
      DOUBLE PRECISION dos(1:nxxx),xw(1:nxxx)
      PARAMETER (pi=3.1415926535898d0)
      
      COMMON /doskram/ dos,xw,bandwidth
      
      
      bandwidth=30.0d0
      dx=bandwidth/dfloat(nxxx)
      
      DO i=1,nxxx
         xw(i)=-bandwidth/2.0+dx*i
         dos(i)=dexp(-xw(i)*xw(i)/pi)
      END DO
***********************************************
*     divide DOS by value at the fermi energy
***********************************************
c      dosnull=1.0d0/dsqrt(pi)
c      DO i=1,nxxx
c         dos(i)=dos(i)/dosnull
c         dos(i)=1.0d0
c      END DO



      RETURN
      END
***********************************************************************
***********************************************************************
      SUBROUTINE GRIDFIND(freq,gam_arr,N,Nadd,ngrid,Gamma,logam,X,
     &     nindex)
      IMPLICIT NONE
      INTEGER N,Nadd,ngrid,nindex
      INTEGER naux,nhelp,iaux
      DOUBLE PRECISION Gamma,logam,X,freq(ngrid),gam_arr(N)
      DOUBLE PRECISION dax
      
      naux=ngrid/2
      dax=dabs(X)
      IF(X.GT.freq(ngrid)) THEN
         nindex=ngrid
      ELSEIF(X.LT.freq(1)) THEN
         nindex=1
      ELSEIF((X.GT.freq(naux)).AND.(X.LT.freq(naux+1))) THEN
         nindex=naux
      ELSEIF(X.GE.freq(naux+1)) THEN
         iaux=INT(log(dax)*logam)
         nhelp=INT((dax*gam_arr(iaux+1)-1.d0)/(Gamma-1.d0)*(Nadd+1))
         nindex=ngrid-iaux*(Nadd+1)-1-(Nadd-nhelp)
      ELSE
         iaux=INT(log(dax)*logam)
         nhelp=INT((dax*gam_arr(iaux+1)-1.d0)/(Gamma-1.d0)*(Nadd+1))
         nindex=iaux*(Nadd+1)+1+(Nadd-nhelp)
      ENDIF
      END
***********************************************************************
***********************************************************************
      SUBROUTINE GRIDFIND2(Dmax,Dmin,N,Nadd,ngrid,Gamma,logam,X,nindex)
      IMPLICIT NONE
      INTEGER N,Nadd,ngrid,nindex
      INTEGER naux,nhelp,iaux
      DOUBLE PRECISION Gamma,logam,X,Dmax,Dmin
      DOUBLE PRECISION dax
      
      naux=ngrid/2
      dax=dabs(X)
      IF(x.GE.0.0d0) THEN
         IF((dax.GE.Dmin).AND.(dax.LT.Dmax)) THEN
            iaux=INT(log(dax)*logam)
            nhelp=INT((dax*Gamma**(iaux+1)-1.d0)/(Gamma-1.d0)*(Nadd+1))
            nindex=ngrid-iaux*(Nadd+1)-1-(Nadd-nhelp)
         ELSEIF(dax.LT.Dmin) THEN
            nindex=naux
         ELSE
            nindex=ngrid
         ENDIF
      ELSE
         IF((dax.GE.Dmin).AND.(dax.LT.Dmax)) THEN
            iaux=INT(log(dax)*logam)
            nhelp=INT((dax*Gamma**(iaux+1)-1.d0)/(Gamma-1.d0)*(Nadd+1))
            nindex=iaux*(Nadd+1)+1+(Nadd-nhelp)
         ELSEIF(dax.LT.Dmin) THEN
            nindex=0
         ELSE
            nindex=naux
         ENDIF    
      END IF
      END
***********************************************************************
***********************************************************************
      SUBROUTINE KRAKRO(n,x,im,re)
c kramers kronig-relation
       implicit double precision (a-h,o-z), integer (i-n)
       double precision x,im,re,lg
       dimension x(n),im(n),re(n),lg(n),dx(n),st(n)

       pi=4d0*datan(1d0)
       do i=1,n
        dx(i)=x(min(n,i+1))-x(max(1,i-1))
        st(i)=(im(min(n,i+1))-im(max(1,i-1)))/dx(i)
        if ((i.gt.1).and.(i.lt.n)) then
         lg(i)=dlog(dabs((x(i)-x(1))/(x(i)-x(n))))*im(i)
        endif
       enddo

       do j=1,n
        re(j)=0d0
        if ((j.gt.1).and.(j.lt.n)) re(j)=-2d0*lg(j)
        do i=1,n
         if (i.ne.j) then
          re(j)=re(j)+(im(i)-im(j))/(x(i)-x(j))*dx(i)
         else
          re(j)=re(j)+st(i)*dx(i)
         endif
        enddo
       enddo
       call dscal(n,-0.5d0/pi,re,1)
      end
***********************************************************************
***********************************************************************
      SUBROUTINE FERMIFUNC0
      IMPLICIT NONE
      INTEGER i,nyyy
      DOUBLE PRECISION x,dx,width
      PARAMETER (nyyy=4000)
      PARAMETER (width=20.0d0)
      DOUBLE PRECISION  fermiown(nyyy+1)
      COMMON /fermikram/ fermiown,dx
      
      dx=width/dfloat(nyyy)
      DO i=1,nyyy+1
         x=(i-1)*dx-width/2.0d0
         IF(x.LE.0.0d0) THEN
            fermiown(i)=1.0d0/(dexp(x)+1.0d0)
         ELSE
            fermiown(i)=dexp(-x)/(dexp(-x)+1.0d0)
         ENDIF
c         fermiown(i)=1.0d0
      END DO

      RETURN
      END
***********************************************************************
***********************************************************************
      DOUBLE PRECISION FUNCTION ferm0(xxx)
      IMPLICIT NONE
      INTEGER i,nyyy
      DOUBLE PRECISION xxx
c      DOUBLE PRECISION width,dx,xxx,xyz,a
c      PARAMETER (nyyy=4000)
c      PARAMETER (width=20.0d0)
c      DOUBLE PRECISION  fermiown(nyyy+1)
c      COMMON /fermikram/ fermiown,dx
c
c      a=width/2.0d0
c      IF (xxx.LT.-a) THEN
c         ferm0=1.0d0
c      ELSEIF(xxx.GE.a) THEN
c         ferm0=0.0d0
c      ELSE
c         xyz=mod(xxx+a,dx)
c         i=(xxx+a)/dx+1
c         ferm0=fermiown(i)+xyz/dx*(fermiown(i+1)-fermiown(i))
c      ENDIF
         IF(xxx.LE.0.0d0) THEN
            ferm0=1.0d0/(dexp(xxx)+1.0d0)
         ELSE
            ferm0=dexp(-xxx)/(dexp(-xxx)+1.0d0)
         ENDIF
      RETURN
      END
***********************************************************************
***********************************************************************
      SUBROUTINE RUPDATEsss(sefm,sefp,sefr,sebm,sebp,sebr,rexp,omega,n,
     &     beta,epsilon,rlambd0)
      IMPLICIT NONE
      INTEGER n,i,k,nspin
      PARAMETER(nspin=2)
      DOUBLE PRECISION omega(n),rlambd0,epsilon
      DOUBLE PRECISION sefm(n),sefp(n),sefr(n),afm(n)
      DOUBLE PRECISION sebm(n),sebp(n),sebr(n),abm(n)
      DOUBLE PRECISION scr(n),rexp(n)
      DOUBLE PRECISION beta,delta,value
      DO i=1,n/2
         k=i+n/2
         afm(i)=sefm(i)/
     &          ((omega(i)-epsilon+rlambd0-sefr(i))**2+sefp(i)**2)
         afm(k)=rexp(n/2-i+1)*sefp(k)/
     &          ((omega(k)-epsilon+rlambd0-sefr(k))**2+sefp(k)**2)
         abm(i)=sebm(i)/
     &          ((omega(i)+rlambd0-sebr(i))**2+sebp(i)**2)
         abm(k)=rexp(n/2-i+1)*sebp(k)/
     &          ((omega(k)+rlambd0-sebr(k))**2+sebp(k)**2)
      END DO


      DO i=1,n
         scr(i)=nspin*afm(i)+abm(i)
      END DO
      
      value=0.0d0
      DO i=1,n-1
         value=value+0.5d0*(scr(i+1)+scr(i))*
     &    (omega(i+1)-omega(i))
      END DO
      delta=-dlog(value)/beta
      rlambd0=rlambd0+delta
      RETURN
      END
***********************************************************************
***********************************************************************
      subroutine dzero(darray,ndim)
      implicit real*8 (a-h,o-z)
      
c---------------------------------------------------------------------
c     initialize array <darray(1,...,ndim)> of floats to zero
c---------------------------------------------------------------------
      
      dimension darray(ndim)
      
      m=mod(ndim,7)
      if  (m.ne.0) then
         do 10 i = 1,m
            darray(i) = 0.0d0
 10      continue
      endif
      mp1 = m + 1
      do 20 i = mp1,ndim,7
         darray(i) = 0.0d0
         darray(i+1) = 0.0d0
         darray(i+2) = 0.0d0
         darray(i+3) = 0.0d0
         darray(i+4) = 0.0d0
         darray(i+5) = 0.0d0
         darray(i+6) = 0.0d0
 20   continue
      return
      end

      subroutine izero(iarray,ndim)
      implicit real*8 (a-h,o-z)
      
c---------------------------------------------------------------------
c     initialize array <darray(1,...,ndim)> of floats to zero
c---------------------------------------------------------------------
      
      dimension iarray(ndim)
      
      m=mod(ndim,7)
      if  (m.ne.0) then
         do 10 i = 1,m
            iarray(i) = 0.0d0
 10      continue
      endif
      mp1 = m + 1
      do 20 i = mp1,ndim,7
         iarray(i) = 0.0d0
         iarray(i+1) = 0.0d0
         iarray(i+2) = 0.0d0
         iarray(i+3) = 0.0d0
         iarray(i+4) = 0.0d0
         iarray(i+5) = 0.0d0
         iarray(i+6) = 0.0d0
 20   continue
      return
      end
