      SUBROUTINE BUILD_RESONANCE_GRID(omega_in,ngrid_in,D,
     &     eps1,sigma1,n1,eps2,sigma2,n2,
     &     omega_out,ngrid_out)

      IMPLICIT NONE

      INTEGER ngrid_in,ngrid_out,n1,n2
      INTEGER ngrid_target
      DOUBLE PRECISION D,eps1,sigma1,eps2,sigma2
      DOUBLE PRECISION omega_in(ngrid_in),omega_out(*)

      ngrid_target = ngrid_in + 2*n1 + 2*n2

      CALL ADD_RESONANCE_GRID(omega_in,ngrid_in,D,
     &     eps1,sigma1,n1,eps2,sigma2,n2,
     &     omega_out,ngrid_out)

      IF (ngrid_out .LT. ngrid_target) THEN
         CALL FILL_TO_TARGET_WIDEST(omega_out,ngrid_out,
     &        ngrid_target)
      ENDIF

      RETURN
      END


      SUBROUTINE ADD_RESONANCE_GRID(omega,ngrid_in,D,
     &     eps1,sigma1,n1,eps2,sigma2,n2,
     &     omega_out,ngrid_out)

      IMPLICIT NONE

      INTEGER ngrid_in,ngrid_out,n1,n2
      INTEGER i,m,muniq
      DOUBLE PRECISION D,eps1,eps2,sigma1,sigma2
      DOUBLE PRECISION omega(ngrid_in),omega_out(*)
      DOUBLE PRECISION work(200000)
      DOUBLE PRECISION tol

      tol = 1.0D-12*DMAX1(1.0D0,D)

c----- remove omega = 0
      m = 0
      DO i=1,ngrid_in
         IF (DABS(omega(i)) .GT. tol) THEN
            m = m + 1
            work(m) = omega(i)
         ENDIF
      END DO

c----- add resonance regions
      CALL ADD_ONE_WINDOW(eps1,sigma1,n1,D,tol,work,m)
      CALL ADD_ONE_WINDOW(eps2,sigma2,n2,D,tol,work,m)

      CALL SORT_ASCENDING(work,m)

c----- remove duplicates
      muniq = 0
      DO i=1,m
         IF (DABS(work(i)) .LE. tol) CYCLE
         IF (muniq .EQ. 0) THEN
            muniq = 1
            omega_out(muniq) = work(i)
         ELSE
            IF (DABS(work(i)-omega_out(muniq)) .GT. tol) THEN
               muniq = muniq + 1
               omega_out(muniq) = work(i)
            ENDIF
         ENDIF
      END DO

      ngrid_out = muniq

      RETURN
      END


      SUBROUTINE ADD_ONE_WINDOW(eps,sigma,n,D,tol,work,m)

      IMPLICIT NONE

      INTEGER n,m,k
      DOUBLE PRECISION eps,sigma,D,tol
      DOUBLE PRECISION work(*)
      DOUBLE PRECISION umax,u,x

      IF (n .LE. 0) RETURN

      umax = DATAN(5.0D0)

      IF (n .EQ. 1) THEN
         x = eps
         CALL ADD_SYM_POINT(x,D,tol,work,m)
         RETURN
      ENDIF

      DO k=1,n
         u = -umax + (2.0D0*umax)*DFLOAT(k-1)/DFLOAT(n-1)
         x = eps + sigma*DTAN(u)
         CALL ADD_SYM_POINT(x,D,tol,work,m)
      END DO

      RETURN
      END


      SUBROUTINE ADD_SYM_POINT(x,D,tol,work,m)

      IMPLICIT NONE

      INTEGER m
      DOUBLE PRECISION x,D,tol
      DOUBLE PRECISION work(*)
      DOUBLE PRECISION xp

      xp = DABS(x)

      IF (xp .LE. tol) RETURN
      IF (xp .GE. D - tol) RETURN

      m = m + 1
      work(m) = -xp
      m = m + 1
      work(m) =  xp

      RETURN
      END


      SUBROUTINE FILL_TO_TARGET_WIDEST(omega,ngrid2,ngrid_target)

      IMPLICIT NONE

      INTEGER ngrid2,ngrid_target
      INTEGER i,j,deficit,npairs,ibest
      DOUBLE PRECISION omega(*)
      DOUBLE PRECISION gap,gapbest,xleft,tol

      tol = 1.0D-12

      deficit = ngrid_target - ngrid2
      npairs = deficit/2

      DO i=1,npairs

         gapbest = -1.0D0
         ibest   = -1

         DO j=1,ngrid2/2-1
            gap = omega(j+1) - omega(j)
            IF (gap .GT. gapbest) THEN
               gapbest = gap
               ibest = j
            ENDIF
         END DO

         xleft = 0.5D0*(omega(ibest) + omega(ibest+1))

         ngrid2 = ngrid2 + 1
         omega(ngrid2) = xleft
         ngrid2 = ngrid2 + 1
         omega(ngrid2) = -xleft

         CALL SORT_ASCENDING(omega,ngrid2)

      END DO

      RETURN
      END


      SUBROUTINE SORT_ASCENDING(a,n)

      IMPLICIT NONE

      INTEGER n,i,j
      DOUBLE PRECISION a(n),tmp

      DO i=2,n
         tmp = a(i)
         j = i - 1
         DO WHILE (j .GE. 1 .AND. a(j) .GT. tmp)
            a(j+1) = a(j)
            j = j - 1
         END DO
         a(j+1) = tmp
      END DO

      RETURN
      END