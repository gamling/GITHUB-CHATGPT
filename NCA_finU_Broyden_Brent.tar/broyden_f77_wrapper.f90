subroutine broyden_f77(m, n, mmax, Fmatrix, Vmatrix, Vout, info)
  use broyden_mixing, only : broyden
  use, intrinsic :: iso_fortran_env, only : real64
  implicit none

  integer, intent(in) :: m, n, mmax
  real(real64), intent(in)  :: Fmatrix(mmax, n)
  real(real64), intent(in)  :: Vmatrix(mmax, n)
  real(real64), intent(out) :: Vout(n)
  integer, intent(out)      :: info

  call broyden(m, n, mmax, Fmatrix, Vmatrix, Vout, info)
end subroutine broyden_f77

