!These are assigned in the main program block:
!
!sp%eta = 0.2_dp
!Controls how strongly the self-energy enters the spectral function.
!sp%tau = 0.2_dp
!Sets the lifetime term through 
!0.5/τ.
!cp%tol_total = 1.0e-6_dp
!Overall target tolerance.
!cp%tol_eps = 1.0e-7_dp
!Tolerance for the inner 
!ϵ-integration.
!cp%tol_nu = 1.0e-6_dp
!Tolerance for the outer 
!ν-integration.
!cp%omega_dc_tol = 1.0e-10_dp
!Threshold below which the code switches from the finite-
!ω formula to the DC routine.
!cp%nu_cut_factor = 24.0_dp
!Controls the size of the 
!ν-integration window.
!cp%eps_window_factor = 20.0_dp
!Controls the width of the 
!ϵ-integration window around the spectral peaks.
!cp%max_recursion = 30
!Maximum recursion depth for adaptive Simpson quadrature.
!
!These are all set in the block around lines 1123–1134.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!DEBUG:
!ifx -g -O0 -traceback -check all -warn all -debug full -standard-semantics -o conductivity_debug conductivity_driver_modified.f90

!PRODUCTION:
!ifx -O2 -warn all -standard-semantics -o conductivity conductivity_driver_modified.f90

module precision
   use, intrinsic :: iso_fortran_env, only: dp => real64
   implicit none
    real(dp), parameter :: pi = 3.1415926535897932384626433832795_dp
end module precision


module rho_spline_mod
  use precision, only: dp
  implicit none
  private

  public :: rho_spline_type
  public :: init_rho_spline, eval_rho_spline, destroy_rho_spline

  real(dp), parameter :: pi = 3.1415926535897932384626433832795d0

  type :: rho_spline_type
     integer :: neps = 0
     real(dp) :: D = 15.0_dp
     real(dp) :: t = 1.0_dp
     real(dp) :: xmax = 300.0_dp
     integer :: nx = 40000
     real(dp) :: rho_floor = 1.0e-14_dp
     logical :: initialized = .false.
     real(dp), allocatable :: eps_grid(:)
     real(dp), allocatable :: rho_grid(:)
     real(dp), allocatable :: log_rho_grid(:)
     real(dp), allocatable :: y2(:)          ! spline second derivatives in log-space
  end type rho_spline_type

contains

  pure real(dp) function kernel_g(x) result(g)
    implicit none
    real(dp), intent(in) :: x
    real(dp) :: j0, j1

    if (abs(x) < 1.0e-12_dp) then
       g = 1.0_dp
    else
       j0 = bessel_j0(x)
       j1 = bessel_j1(x)
       g = 2.0_dp * j0*j0 * j1 / x
    end if
  end function kernel_g


  subroutine build_rho_grid(neps, eps_grid, t, xmax, nx, rho_grid)
    implicit none
    integer, intent(in) :: neps, nx
    real(dp), intent(in) :: eps_grid(neps), t, xmax
    real(dp), intent(out) :: rho_grid(neps)

    integer :: i, k
    real(dp) :: h, x, w, pref
    real(dp), allocatable :: g(:)

    if (t <= 0.0_dp) stop "build_rho_grid: t must be > 0"
    if (nx <= 0 .or. mod(nx,2) /= 0) stop "build_rho_grid: nx must be positive and even"

    h = xmax / dble(nx)
    pref = (h/3.0_dp) / (2.0_dp*pi*t)

    allocate(g(0:nx))

    do i = 0, nx
       x = dble(i) * h
       g(i) = kernel_g(x)
    end do

    rho_grid = 0.0_dp

    do i = 0, nx
       x = dble(i) * h

       if (i == 0 .or. i == nx) then
          w = 1.0_dp
       else if (mod(i,2) == 1) then
          w = 4.0_dp
       else
          w = 2.0_dp
       end if

       do k = 1, neps
          rho_grid(k) = rho_grid(k) + w * cos((eps_grid(k)/(2.0_dp*t))*x) * g(i)
       end do
    end do

    rho_grid = pref * rho_grid

    deallocate(g)
  end subroutine build_rho_grid


  subroutine spline_natural(x, y, n, y2)
    ! Natural cubic spline: computes second derivatives y2(:)
    implicit none
    integer, intent(in) :: n
    real(dp), intent(in) :: x(n), y(n)
    real(dp), intent(out) :: y2(n)

    integer :: i, k
    real(dp) :: p, qn, sig, un
    real(dp), allocatable :: u(:)

    allocate(u(n))

    y2(1) = 0.0_dp
    u(1)  = 0.0_dp

    do i = 2, n-1
       sig = (x(i) - x(i-1)) / (x(i+1) - x(i-1))
       p   = sig*y2(i-1) + 2.0d0
       y2(i) = (sig - 1.0_dp) / p
       u(i) = ( 6.0_dp * ( (y(i+1)-y(i))/(x(i+1)-x(i)) - (y(i)-y(i-1))/(x(i)-x(i-1)) ) &
              / (x(i+1)-x(i-1)) - sig*u(i-1) ) / p
    end do

    qn = 0.0_dp
    un = 0.0_dp
    y2(n) = (un - qn*u(n-1)) / (qn*y2(n-1) + 1.0_dp)

    do k = n-1, 1, -1
       y2(k) = y2(k)*y2(k+1) + u(k)
    end do

    deallocate(u)
  end subroutine spline_natural


  real(dp) function spline_eval(xa, ya, y2a, n, x) result(y)
    implicit none
    integer, intent(in) :: n
    real(dp), intent(in) :: xa(n), ya(n), y2a(n), x
    integer :: klo, khi, k
    real(dp) :: a, b, h

    klo = 1
    khi = n

    do while (khi-klo > 1)
       k = (khi+klo)/2
       if (xa(k) > x) then
          khi = k
       else
          klo = k
       end if
    end do

    h = xa(khi) - xa(klo)
    if (h == 0.0_dp) stop "spline_eval: bad xa input"

    a = (xa(khi) - x) / h
    b = (x - xa(klo)) / h

    y = a*ya(klo) + b*ya(khi) + ((a**3-a)*y2a(klo) + (b**3-b)*y2a(khi)) * (h*h)/6.0_dp
  end function spline_eval


  subroutine init_rho_spline(rho_obj, t, neps, D, xmax, nx, rho_floor)
    implicit none
    type(rho_spline_type), intent(inout) :: rho_obj
    real(dp), intent(in) :: t
    integer, intent(in), optional :: neps, nx
    real(dp), intent(in), optional :: D, xmax, rho_floor

    integer :: i, nloc
    real(dp) :: Dloc, xmaxloc, floorloc

    if (present(neps)) then
       nloc = neps
    else
       nloc = 4001
    end if

    if (present(D)) then
       Dloc = D
    else
       Dloc = 15.0_dp
    end if

    if (present(xmax)) then
       xmaxloc = xmax
    else
       xmaxloc = 300.0_dp
    end if

    if (present(nx)) then
       rho_obj%nx = nx
    else
       rho_obj%nx = 40000
    end if

    if (present(rho_floor)) then
       floorloc = rho_floor
    else
       floorloc = 1.0e-14_dp
    end if

    if (allocated(rho_obj%eps_grid))      deallocate(rho_obj%eps_grid)
    if (allocated(rho_obj%rho_grid))      deallocate(rho_obj%rho_grid)
    if (allocated(rho_obj%log_rho_grid))  deallocate(rho_obj%log_rho_grid)
    if (allocated(rho_obj%y2))            deallocate(rho_obj%y2)

    rho_obj%neps = nloc
    rho_obj%D = Dloc
    rho_obj%t = t
    rho_obj%xmax = xmaxloc
    rho_obj%rho_floor = floorloc

    allocate(rho_obj%eps_grid(nloc))
    allocate(rho_obj%rho_grid(nloc))
    allocate(rho_obj%log_rho_grid(nloc))
    allocate(rho_obj%y2(nloc))

    do i = 1, nloc
       rho_obj%eps_grid(i) = -Dloc + 2.0_dp*Dloc*dble(i-1)/dble(nloc-1)
    end do

    call build_rho_grid(nloc, rho_obj%eps_grid, t, xmaxloc, rho_obj%nx, rho_obj%rho_grid)

    ! Enforce semi-positivity on the tabulated grid:
    do i = 1, nloc
       if (rho_obj%rho_grid(i) < 0.0_dp) rho_obj%rho_grid(i) = 0.0_dp
       rho_obj%log_rho_grid(i) = log(rho_obj%rho_grid(i) + floorloc)
    end do

    call spline_natural(rho_obj%eps_grid, rho_obj%log_rho_grid, nloc, rho_obj%y2)

    rho_obj%initialized = .true.
  end subroutine init_rho_spline


  real(dp) function eval_rho_spline(rho_obj, eps) result(rho)
    implicit none
    type(rho_spline_type), intent(in) :: rho_obj
    real(dp), intent(in) :: eps
    real(dp) :: logv

    if (.not. rho_obj%initialized) stop "eval_rho_spline: spline object not initialized"

    if (eps <= -rho_obj%D .or. eps >= rho_obj%D) then
       rho = 0.0_dp
       return
    end if

    logv = spline_eval(rho_obj%eps_grid, rho_obj%log_rho_grid, rho_obj%y2, rho_obj%neps, eps)

    rho = exp(logv) - rho_obj%rho_floor

    if (rho < 0.0_dp) rho = 0.0_dp
  end function eval_rho_spline


  subroutine destroy_rho_spline(rho_obj)
    implicit none
    type(rho_spline_type), intent(inout) :: rho_obj

    if (allocated(rho_obj%eps_grid))      deallocate(rho_obj%eps_grid)
    if (allocated(rho_obj%rho_grid))      deallocate(rho_obj%rho_grid)
    if (allocated(rho_obj%log_rho_grid))  deallocate(rho_obj%log_rho_grid)
    if (allocated(rho_obj%y2))            deallocate(rho_obj%y2)

    rho_obj%initialized = .false.
    rho_obj%neps = 0
  end subroutine destroy_rho_spline

end module rho_spline_mod

!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
module thermal_distribution_module
   use, intrinsic :: iso_fortran_env, only : dp => real64
   implicit none
   private

   public :: set_thermal_beta, get_thermal_beta
   public :: fermi, bose
   public :: thermal_weight_pos, thermal_weight_dc

   real(dp), save :: beta_current = 1.0_dp
   real(dp), save :: x_overflow   = 0.0_dp
   real(dp), parameter :: x_small = 1.0e-8_dp

contains

   subroutine set_thermal_beta(beta)
      real(dp), intent(in) :: beta
      if (beta < 0.0_dp) error stop 'set_thermal_beta: beta must be >= 0'
      beta_current = beta
      x_overflow   = log(huge(1.0_dp))
   end subroutine set_thermal_beta

   pure function get_thermal_beta() result(beta)
      real(dp) :: beta
      beta = beta_current
   end function get_thermal_beta

   pure elemental function fermi(eps) result(f)
      real(dp), intent(in) :: eps
      real(dp)             :: f
      real(dp)             :: x, t

      if (beta_current == 0.0_dp) then
         f = 0.5_dp
         return
      end if

      x = beta_current * eps

      if (x >= x_overflow) then
         f = 0.0_dp
      else if (x <= -x_overflow) then
         f = 1.0_dp
      else if (x >= 0.0_dp) then
         t = exp(-x)
         f = t / (1.0_dp + t)
      else
         t = exp(x)
         f = 1.0_dp / (1.0_dp + t)
      end if
   end function fermi

   pure elemental function bose(eps) result(b)
      real(dp), intent(in) :: eps
      real(dp)             :: b
      real(dp)             :: x

      if (beta_current == 0.0_dp) error stop 'bose: beta=0 is singular'

      x = beta_current * eps

      if (x == 0.0_dp) then
         b = huge(1.0_dp)
      else if (x >= x_overflow) then
         b = 0.0_dp
      else if (abs(x) < x_small) then
         b = 1.0_dp/x - 0.5_dp + x/12.0_dp
      else
         b = 1.0_dp / (exp(x) - 1.0_dp)
      end if
   end function bose


   pure elemental function thermal_weight_pos(nu, omega) result(w)
   ! Stable thermal factor for conductivity for omega > 0:
   !
   !    w = f(-nu-omega) f(nu) / ( omega * b(-omega) )
   !
   ! For small beta*omega, expand only the Bose denominator:
   !
   !    1 / (omega * b(-omega)) = -beta + O(beta^2 * omega)
   !
   real(dp), intent(in) :: nu, omega
   real(dp)             :: w
   real(dp)             :: x

   if (omega <= 0.0_dp) error stop 'thermal_weight_pos: omega must be > 0'

   x = beta_current * omega

   if (abs(x) < 1.0e-4_dp) then
      ! Keep the two Fermi factors exact; regularize only the Bose part
      w = -beta_current * fermi(-nu-omega) * fermi(nu)
   else
      w = fermi(-nu-omega) * fermi(nu) / (omega * bose(-omega))
   end if
end function thermal_weight_pos


   pure elemental function thermal_weight_dc(nu) result(w0)
      real(dp), intent(in) :: nu
      real(dp)             :: w0
      real(dp)             :: fnu

      if (beta_current == 0.0_dp) then
         w0 = 0.0_dp
      else
         fnu = fermi(nu)
         w0  = -beta_current * fnu * (1.0_dp - fnu)
      end if
   end function thermal_weight_dc

end module thermal_distribution_module


module selfenergy_interp_mod
   use precision, only : dp
   implicit none
   private

   public :: selfenergy_type
   public :: init_selfenergy, destroy_selfenergy
   public :: sigma_re_eval, sigma_im_eval
   public :: omega_min_se, omega_max_se

   type :: selfenergy_type
      integer :: n = 0
      logical :: initialized = .false.
      real(dp), allocatable :: omega(:)
      real(dp), allocatable :: sig_re(:)
      real(dp), allocatable :: sig_im(:)
   end type selfenergy_type

contains

   subroutine init_selfenergy(se_obj, omega, sig_re, sig_im)
      type(selfenergy_type), intent(inout) :: se_obj
      real(dp), intent(in) :: omega(:), sig_re(:), sig_im(:)
      integer :: n, i

      n = size(omega)
      if (size(sig_re) /= n .or. size(sig_im) /= n) error stop 'init_selfenergy: size mismatch'
      if (n < 2) error stop 'init_selfenergy: need at least 2 points'

      do i = 2, n
         if (omega(i) <= omega(i-1)) error stop 'init_selfenergy: omega grid must be strictly increasing'
      end do

      if (allocated(se_obj%omega))  deallocate(se_obj%omega)
      if (allocated(se_obj%sig_re)) deallocate(se_obj%sig_re)
      if (allocated(se_obj%sig_im)) deallocate(se_obj%sig_im)

      allocate(se_obj%omega(n), se_obj%sig_re(n), se_obj%sig_im(n))
      se_obj%omega  = omega
      se_obj%sig_re = sig_re
      se_obj%sig_im = max(sig_im, 0.0_dp)

      se_obj%n = n
      se_obj%initialized = .true.
   end subroutine init_selfenergy

   subroutine destroy_selfenergy(se_obj)
      type(selfenergy_type), intent(inout) :: se_obj
      if (allocated(se_obj%omega))  deallocate(se_obj%omega)
      if (allocated(se_obj%sig_re)) deallocate(se_obj%sig_re)
      if (allocated(se_obj%sig_im)) deallocate(se_obj%sig_im)
      se_obj%n = 0
      se_obj%initialized = .false.
   end subroutine destroy_selfenergy

   pure integer function locate_interval(x, grid, n) result(idx)
      real(dp), intent(in) :: x
      integer, intent(in) :: n
      real(dp), intent(in) :: grid(n)
      integer :: lo, hi, mid

      if (x <= grid(1)) then
         idx = 1
         return
      end if
      if (x >= grid(n)) then
         idx = n-1
         return
      end if

      lo = 1
      hi = n
      do while (hi - lo > 1)
         mid = (lo + hi) / 2
         if (grid(mid) <= x) then
            lo = mid
         else
            hi = mid
         end if
      end do
      idx = lo
   end function locate_interval

   pure function lin_interp(x, grid, vals, n) result(v)
      real(dp), intent(in) :: x
      integer, intent(in)  :: n
      real(dp), intent(in) :: grid(n), vals(n)
      real(dp) :: v
      integer  :: i
      real(dp) :: t

      if (x <= grid(1)) then
         i = 1
      else if (x >= grid(n)) then
         i = n-1
      else
         i = locate_interval(x, grid, n)
      end if

      t = (x - grid(i)) / (grid(i+1) - grid(i))
      v = (1.0_dp - t) * vals(i) + t * vals(i+1)
   end function lin_interp

   pure function sigma_re_eval(se_obj, w) result(val)
      type(selfenergy_type), intent(in) :: se_obj
      real(dp), intent(in) :: w
      real(dp) :: val

      if (.not. se_obj%initialized) error stop 'sigma_re_eval: selfenergy not initialized'
      val = lin_interp(w, se_obj%omega, se_obj%sig_re, se_obj%n)
   end function sigma_re_eval

   pure function sigma_im_eval(se_obj, w) result(val)
      type(selfenergy_type), intent(in) :: se_obj
      real(dp), intent(in) :: w
      real(dp) :: val

      if (.not. se_obj%initialized) error stop 'sigma_im_eval: selfenergy not initialized'
      val = max(0.0_dp, lin_interp(w, se_obj%omega, se_obj%sig_im, se_obj%n))
   end function sigma_im_eval

   pure function omega_min_se(se_obj) result(wmin)
      type(selfenergy_type), intent(in) :: se_obj
      real(dp) :: wmin
      if (.not. se_obj%initialized) error stop 'omega_min_se: selfenergy not initialized'
      wmin = se_obj%omega(1)
   end function omega_min_se

   pure function omega_max_se(se_obj) result(wmax)
      type(selfenergy_type), intent(in) :: se_obj
      real(dp) :: wmax
      if (.not. se_obj%initialized) error stop 'omega_max_se: selfenergy not initialized'
      wmax = se_obj%omega(se_obj%n)
   end function omega_max_se

end module selfenergy_interp_mod


module rhotilde_mod
   use precision, only : dp
   use rho_spline_mod, only : rho_spline_type, init_rho_spline, eval_rho_spline, destroy_rho_spline
   implicit none
   private

   public :: rhotilde_type
   public :: init_rhotilde, destroy_rhotilde, rhotilde_eval
   public :: eps_min_rho, eps_max_rho

   type :: rhotilde_type
      type(rho_spline_type) :: rho_obj
      logical :: initialized = .false.
   end type rhotilde_type

contains

   subroutine init_rhotilde(rt_obj, t_hop, neps, D, xmax, nx, rho_floor)
      type(rhotilde_type), intent(inout) :: rt_obj
      real(dp), intent(in) :: t_hop
      integer, intent(in), optional :: neps, nx
      real(dp), intent(in), optional :: D, xmax, rho_floor

      call init_rho_spline(rt_obj%rho_obj, t=t_hop, neps=neps, D=D, xmax=xmax, nx=nx, rho_floor=rho_floor)
      rt_obj%initialized = .true.
   end subroutine init_rhotilde

   subroutine destroy_rhotilde(rt_obj)
      type(rhotilde_type), intent(inout) :: rt_obj
      call destroy_rho_spline(rt_obj%rho_obj)
      rt_obj%initialized = .false.
   end subroutine destroy_rhotilde

   function rhotilde_eval(rt_obj, eps) result(val)
      type(rhotilde_type), intent(in) :: rt_obj
      real(dp), intent(in) :: eps
      real(dp) :: val
      if (.not. rt_obj%initialized) error stop 'rhotilde_eval: object not initialized'
      val = eval_rho_spline(rt_obj%rho_obj, eps)
   end function rhotilde_eval

   function eps_min_rho(rt_obj) result(emin)
      type(rhotilde_type), intent(in) :: rt_obj
      real(dp) :: emin
      emin = -rt_obj%rho_obj%D
   end function eps_min_rho

   function eps_max_rho(rt_obj) result(emax)
      type(rhotilde_type), intent(in) :: rt_obj
      real(dp) :: emax
      emax = rt_obj%rho_obj%D
   end function eps_max_rho

end module rhotilde_mod


module spectral_mod
   use precision, only : dp
   use selfenergy_interp_mod, only : selfenergy_type, sigma_re_eval, sigma_im_eval
   implicit none
   private

   public :: spectral_params_type
   public :: gamma_eval, xcenter_eval, spectral_A

   type :: spectral_params_type
      real(dp) :: eta = 1.0_dp
      real(dp) :: tau = 1.0_dp
      real(dp) :: gamma_floor = 1.0e-12_dp
   end type spectral_params_type

contains

   pure function gamma_eval(se_obj, sp, w) result(gam)
      type(selfenergy_type), intent(in) :: se_obj
      type(spectral_params_type), intent(in) :: sp
      real(dp), intent(in) :: w
      real(dp) :: gam

      gam = 0.5_dp / sp%tau + sp%eta * sigma_im_eval(se_obj, w)
      gam = max(gam, sp%gamma_floor)
   end function gamma_eval

   pure function xcenter_eval(se_obj, sp, w) result(xc)
      type(selfenergy_type), intent(in) :: se_obj
      type(spectral_params_type), intent(in) :: sp
      real(dp), intent(in) :: w
      real(dp) :: xc

      xc = w - sp%eta * sigma_re_eval(se_obj, w)
   end function xcenter_eval

   pure function spectral_A(eps, w, se_obj, sp) result(A)
      type(selfenergy_type), intent(in) :: se_obj
      type(spectral_params_type), intent(in) :: sp
      real(dp), intent(in) :: eps, w
      real(dp) :: A
      real(dp) :: gam, xc, den

      gam = gamma_eval(se_obj, sp, w)
      xc  = xcenter_eval(se_obj, sp, w)

      den = (eps - xc)**2 + gam**2
      A   = gam / den
   end function spectral_A

end module spectral_mod


module quadrature_mod
   use precision, only : dp
   implicit none
   private
   public :: adaptive_simpson_interval

contains

   recursive function adaptive_simpson_interval(func, a, b, fa, fm, fb, s, tol, depth) result(res)
      interface
         function func(x) result(val)
            use precision, only : dp
            real(dp), intent(in) :: x
            real(dp) :: val
         end function func
      end interface

      real(dp), intent(in) :: a, b, fa, fm, fb, s, tol
      integer, intent(in)  :: depth
      real(dp) :: res
      real(dp) :: m, lm, rm, flm, frm, sleft, sright, serr

      m  = 0.5_dp * (a + b)
      lm = 0.5_dp * (a + m)
      rm = 0.5_dp * (m + b)

      flm = func(lm)
      frm = func(rm)

      sleft  = (m - a) * (fa + 4.0_dp*flm + fm) / 6.0_dp
      sright = (b - m) * (fm + 4.0_dp*frm + fb) / 6.0_dp
      serr   = abs(sleft + sright - s)

      if (depth <= 0 .or. serr <= 15.0_dp * tol) then
         res = sleft + sright + (sleft + sright - s) / 15.0_dp
      else
         res = adaptive_simpson_interval(func, a, m, fa, flm, fm, sleft, 0.5_dp*tol, depth-1) + &
               adaptive_simpson_interval(func, m, b, fm, frm, fb, sright, 0.5_dp*tol, depth-1)
      end if
   end function adaptive_simpson_interval

end module quadrature_mod


module conductivity_mod
   use precision, only : dp, pi
   use thermal_distribution_module, only : get_thermal_beta, thermal_weight_pos, thermal_weight_dc
   use selfenergy_interp_mod, only : selfenergy_type, omega_min_se, omega_max_se
   use rhotilde_mod, only : rhotilde_type, rhotilde_eval, eps_min_rho, eps_max_rho
   use spectral_mod, only : spectral_params_type, spectral_A, gamma_eval, xcenter_eval
   use quadrature_mod, only : adaptive_simpson_interval
   implicit none
   private

   public :: conductivity_params_type
   public :: sigma_re, sigma_re_pos, sigma_re_dc

   type :: conductivity_params_type
      real(dp) :: t_hop = 1.0_dp
      real(dp) :: tol_total = 1.0e-6_dp
      real(dp) :: tol_eps   = 1.0e-7_dp
      real(dp) :: tol_nu    = 1.0e-6_dp
      real(dp) :: omega_dc_tol = 1.0e-8_dp
      real(dp) :: nu_cut_factor = 24.0_dp
      real(dp) :: eps_window_factor = 20.0_dp
      integer  :: max_recursion = 20
   end type conductivity_params_type

contains

   function sigma_re(omega, se_obj, rt_obj, sp, cp) result(sig)
      real(dp), intent(in) :: omega
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: sig

      if (abs(omega) < cp%omega_dc_tol) then
         sig = sigma_re_dc(se_obj, rt_obj, sp, cp)
      else
         sig = sigma_re_pos(abs(omega), se_obj, rt_obj, sp, cp)
      end if
   end function sigma_re

   function sigma_re_pos(omega, se_obj, rt_obj, sp, cp) result(sig)
      real(dp), intent(in) :: omega
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: sig
      real(dp) :: nu_a, nu_b, fa, fm, fb, s0

      if (omega <= 0.0_dp) error stop 'sigma_re_pos: omega must be > 0'

      call estimate_nu_window(omega, se_obj, cp, nu_a, nu_b)

      fa = nu_integrand(nu_a, omega, se_obj, rt_obj, sp, cp)
      fm = nu_integrand(0.5_dp*(nu_a+nu_b), omega, se_obj, rt_obj, sp, cp)
      fb = nu_integrand(nu_b, omega, se_obj, rt_obj, sp, cp)
      s0 = (nu_b - nu_a) * (fa + 4.0_dp*fm + fb) / 6.0_dp

      sig = (12.0_dp * cp%t_hop * cp%t_hop / pi) * &
            adaptive_simpson_interval(f_nu, nu_a, nu_b, fa, fm, fb, s0, cp%tol_nu, cp%max_recursion)

   contains
      function f_nu(nu) result(val)
         real(dp), intent(in) :: nu
         real(dp) :: val
         val = nu_integrand(nu, omega, se_obj, rt_obj, sp, cp)
      end function f_nu
   end function sigma_re_pos

   function sigma_re_dc(se_obj, rt_obj, sp, cp) result(sig0)
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: sig0
      real(dp) :: nu_a, nu_b, fa, fm, fb, s0

      call estimate_nu_window(0.0_dp, se_obj, cp, nu_a, nu_b)

      fa = nu_integrand_dc(nu_a, se_obj, rt_obj, sp, cp)
      fm = nu_integrand_dc(0.5_dp*(nu_a+nu_b), se_obj, rt_obj, sp, cp)
      fb = nu_integrand_dc(nu_b, se_obj, rt_obj, sp, cp)
      s0 = (nu_b - nu_a) * (fa + 4.0_dp*fm + fb) / 6.0_dp

      sig0 = (12.0_dp * cp%t_hop * cp%t_hop / pi) * &
             adaptive_simpson_interval(f_nu_dc, nu_a, nu_b, fa, fm, fb, s0, cp%tol_nu, cp%max_recursion)

   contains
      function f_nu_dc(nu) result(val)
         real(dp), intent(in) :: nu
         real(dp) :: val
         val = nu_integrand_dc(nu, se_obj, rt_obj, sp, cp)
      end function f_nu_dc
   end function sigma_re_dc

   function nu_integrand(nu, omega, se_obj, rt_obj, sp, cp) result(val)
      real(dp), intent(in) :: nu, omega
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: val

      val = thermal_weight_pos(nu, omega) * kernel_eps_refined(nu, omega, se_obj, rt_obj, sp, cp)
   end function nu_integrand

   function nu_integrand_dc(nu, se_obj, rt_obj, sp, cp) result(val)
      real(dp), intent(in) :: nu
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: val

      val = thermal_weight_dc(nu) * kernel_eps_dc_refined(nu, se_obj, rt_obj, sp, cp)
   end function nu_integrand_dc

!   function kernel_eps(nu, omega, se_obj, rt_obj, sp, cp) result(kern)
!      real(dp), intent(in) :: nu, omega
!      type(selfenergy_type), intent(in) :: se_obj
!      type(rhotilde_type), intent(in) :: rt_obj
!      type(spectral_params_type), intent(in) :: sp
!      type(conductivity_params_type), intent(in) :: cp
!      real(dp) :: kern
!      real(dp) :: eps_a, eps_b, fa, fm, fb, s0
!
!      call estimate_eps_window(nu, omega, se_obj, rt_obj, sp, cp, eps_a, eps_b)
!
!      if (eps_b <= eps_a) then
!         kern = 0.0_dp
!         return
!      end if
!
!      fa = f_eps(eps_a)
!      fm = f_eps(0.5_dp*(eps_a+eps_b))
!      fb = f_eps(eps_b)
!      s0 = (eps_b - eps_a) * (fa + 4.0_dp*fm + fb) / 6.0_dp
!
!      kern = adaptive_simpson_interval(f_eps, eps_a, eps_b, fa, fm, fb, s0, cp%tol_eps, cp%max_recursion)
!
!   contains
!      function f_eps(eps) result(val)
!         real(dp), intent(in) :: eps
!         real(dp) :: val
!         val = rhotilde_eval(rt_obj, eps) * &
!               spectral_A(eps, nu+omega, se_obj, sp) * &
!               spectral_A(eps, nu,       se_obj, sp)
!      end function f_eps
!   end function kernel_eps

!   function kernel_eps_dc(nu, se_obj, rt_obj, sp, cp) result(kern)
!      real(dp), intent(in) :: nu
!      type(selfenergy_type), intent(in) :: se_obj
!      type(rhotilde_type), intent(in) :: rt_obj
!      type(spectral_params_type), intent(in) :: sp
!      type(conductivity_params_type), intent(in) :: cp
!      real(dp) :: kern
!      real(dp) :: eps_a, eps_b, fa, fm, fb, s0
!
!      call estimate_eps_window(nu, 0.0_dp, se_obj, rt_obj, sp, cp, eps_a, eps_b)
!
!      if (eps_b <= eps_a) then
!         kern = 0.0_dp
!         return
!      end if
!
!      fa = f_eps_dc(eps_a)
!      fm = f_eps_dc(0.5_dp*(eps_a+eps_b))
!      fb = f_eps_dc(eps_b)
!      s0 = (eps_b - eps_a) * (fa + 4.0_dp*fm + fb) / 6.0_dp
!
!      kern = adaptive_simpson_interval(f_eps_dc, eps_a, eps_b, fa, fm, fb, s0, cp%tol_eps, cp%max_recursion)
!
!   contains
!      function f_eps_dc(eps) result(val)
!         real(dp), intent(in) :: eps
!         real(dp) :: val
!         real(dp) :: a0
!         a0 = spectral_A(eps, nu, se_obj, sp)
!         val = rhotilde_eval(rt_obj, eps) * a0 * a0
!      end function f_eps_dc
!   end function kernel_eps_dc

   subroutine estimate_nu_window(omega, se_obj, cp, nu_min, nu_max)
      real(dp), intent(in) :: omega
      type(selfenergy_type), intent(in) :: se_obj
      type(conductivity_params_type), intent(in) :: cp
      real(dp), intent(out) :: nu_min, nu_max
      real(dp) :: beta, thermal_span, se_span

      beta = get_thermal_beta()
      if (beta > 0.0_dp) then
         thermal_span = cp%nu_cut_factor / beta
      else
         thermal_span = cp%nu_cut_factor
      end if

      se_span = max(abs(omega_min_se(se_obj)), abs(omega_max_se(se_obj)))

      nu_min = -max(thermal_span + 2.0_dp*abs(omega), se_span)
      nu_max =  max(thermal_span + 2.0_dp*abs(omega), se_span)
   end subroutine estimate_nu_window

 !  subroutine estimate_eps_window(nu, omega, se_obj, rt_obj, sp, cp, eps_a, eps_b)
 !     real(dp), intent(in) :: nu, omega
 !     type(selfenergy_type), intent(in) :: se_obj
 !     type(rhotilde_type), intent(in) :: rt_obj
 !     type(spectral_params_type), intent(in) :: sp
 !     type(conductivity_params_type), intent(in) :: cp
 !     real(dp), intent(out) :: eps_a, eps_b
 !     real(dp) :: c1, c2, g1, g2, width
!
!      c1 = xcenter_eval(se_obj, sp, nu+omega)
!      c2 = xcenter_eval(se_obj, sp, nu)
!      g1 = gamma_eval(se_obj, sp, nu+omega)
!      g2 = gamma_eval(se_obj, sp, nu)
!
!      width = max(max(g1, g2), max(abs(c1-c2), 1.0_dp))
!
!      eps_a = max(eps_min_rho(rt_obj), min(c1, c2) - cp%eps_window_factor * width)
!      eps_b = min(eps_max_rho(rt_obj), max(c1, c2) + cp%eps_window_factor * width)
!   end subroutine estimate_eps_window

   function kernel_eps_refined(nu, omega, se_obj, rt_obj, sp, cp) result(kern)
      real(dp), intent(in) :: nu, omega
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: kern

      integer, parameter :: max_intervals = 8
      real(dp) :: a(max_intervals), b(max_intervals)
      integer :: nint, i
      real(dp) :: fa, fm, fb, s0

      call build_eps_intervals(nu, omega, se_obj, rt_obj, sp, cp, a, b, nint)

      kern = 0.0_dp
      do i = 1, nint
         if (b(i) <= a(i)) cycle

         fa = f_eps(a(i))
         fm = f_eps(0.5_dp * (a(i) + b(i)))
         fb = f_eps(b(i))
         s0 = (b(i) - a(i)) * (fa + 4.0_dp*fm + fb) / 6.0_dp

         kern = kern + adaptive_simpson_interval( &
              f_eps, a(i), b(i), fa, fm, fb, s0, cp%tol_eps, cp%max_recursion)
      end do

   contains
      function f_eps(eps) result(val)
         real(dp), intent(in) :: eps
         real(dp) :: val
         val = rhotilde_eval(rt_obj, eps) * &
               spectral_A(eps, nu+omega, se_obj, sp) * &
               spectral_A(eps, nu,       se_obj, sp)
      end function f_eps
   end function kernel_eps_refined


   function kernel_eps_dc_refined(nu, se_obj, rt_obj, sp, cp) result(kern)
      real(dp), intent(in) :: nu
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp) :: kern

      integer, parameter :: max_intervals = 8
      real(dp) :: a(max_intervals), b(max_intervals)
      integer :: nint, i
      real(dp) :: fa, fm, fb, s0

      call build_eps_intervals(nu, 0.0_dp, se_obj, rt_obj, sp, cp, a, b, nint)

      kern = 0.0_dp
      do i = 1, nint
         if (b(i) <= a(i)) cycle

         fa = f_eps_dc(a(i))
         fm = f_eps_dc(0.5_dp * (a(i) + b(i)))
         fb = f_eps_dc(b(i))
         s0 = (b(i) - a(i)) * (fa + 4.0_dp*fm + fb) / 6.0_dp

         kern = kern + adaptive_simpson_interval( &
              f_eps_dc, a(i), b(i), fa, fm, fb, s0, cp%tol_eps, cp%max_recursion)
      end do

   contains
      function f_eps_dc(eps) result(val)
         real(dp), intent(in) :: eps
         real(dp) :: val
         real(dp) :: a0
         a0 = spectral_A(eps, nu, se_obj, sp)
         val = rhotilde_eval(rt_obj, eps) * a0 * a0
      end function f_eps_dc
   end function kernel_eps_dc_refined


   subroutine build_eps_intervals(nu, omega, se_obj, rt_obj, sp, cp, a, b, nint)
      real(dp), intent(in) :: nu, omega
      type(selfenergy_type), intent(in) :: se_obj
      type(rhotilde_type), intent(in) :: rt_obj
      type(spectral_params_type), intent(in) :: sp
      type(conductivity_params_type), intent(in) :: cp
      real(dp), intent(out) :: a(:), b(:)
      integer, intent(out) :: nint

      real(dp) :: c1, c2, g1, g2
      real(dp) :: g1eff, g2eff, gscale, sep, floor_w
      real(dp) :: amin, bmax
      integer :: nraw

      nint = 0
      nraw = 0

      c1 = xcenter_eval(se_obj, sp, nu+omega)
      c2 = xcenter_eval(se_obj, sp, nu)
      g1 = gamma_eval(se_obj, sp, nu+omega)
      g2 = gamma_eval(se_obj, sp, nu)

      ! Small numerical floor only to avoid zero-width intervals.
      floor_w = 1.0e-8_dp
      g1eff = max(g1, floor_w)
      g2eff = max(g2, floor_w)

      sep    = abs(c1 - c2)
      gscale = max(g1eff, g2eff)

      ! 1) interval around first peak
      nraw = nraw + 1
      a(nraw) = c1 - cp%eps_window_factor * g1eff
      b(nraw) = c1 + cp%eps_window_factor * g1eff

      ! 2) interval around second peak
      nraw = nraw + 1
      a(nraw) = c2 - cp%eps_window_factor * g2eff
      b(nraw) = c2 + cp%eps_window_factor * g2eff

      ! 3) safety interval covering both peaks and the region between them
      amin = min(c1, c2) - cp%eps_window_factor * gscale
      bmax = max(c1, c2) + cp%eps_window_factor * gscale

    !  ! widen slightly if the peaks are well separated
    !  amin = amin - 0.5_dp * sep
    !  bmax = bmax + 0.5_dp * sep

      nraw = nraw + 1
      a(nraw) = amin
      b(nraw) = bmax

      ! Clip to rho support
      call clip_intervals_to_rho(rt_obj, a, b, nraw)

      ! Sort and merge overlapping intervals
      call sort_intervals(a, b, nraw)
      call merge_intervals(a, b, nraw, nint)
   end subroutine build_eps_intervals


   subroutine clip_intervals_to_rho(rt_obj, a, b, n)
      type(rhotilde_type), intent(in) :: rt_obj
      real(dp), intent(inout) :: a(:), b(:)
      integer, intent(in) :: n
      integer :: i
      real(dp) :: lo, hi

      lo = eps_min_rho(rt_obj)
      hi = eps_max_rho(rt_obj)

      do i = 1, n
         a(i) = max(a(i), lo)
         b(i) = min(b(i), hi)
      end do
   end subroutine clip_intervals_to_rho


   subroutine sort_intervals(a, b, n)
      real(dp), intent(inout) :: a(:), b(:)
      integer, intent(in) :: n
      integer :: i, j
      real(dp) :: ta, tb

      do i = 1, n-1
         do j = i+1, n
            if (a(j) < a(i)) then
               ta = a(i); tb = b(i)
               a(i) = a(j); b(i) = b(j)
               a(j) = ta;   b(j) = tb
            end if
         end do
      end do
   end subroutine sort_intervals


   subroutine merge_intervals(a, b, nraw, nout)
      real(dp), intent(inout) :: a(:), b(:)
      integer, intent(in) :: nraw
      integer, intent(out) :: nout

      integer :: i, k
      real(dp) :: tol_merge

      tol_merge = 1.0e-12_dp
      nout = 0

      do i = 1, nraw
         if (b(i) <= a(i)) cycle

         if (nout == 0) then
            nout = 1
            a(nout) = a(i)
            b(nout) = b(i)
         else
            k = nout
            if (a(i) <= b(k) + tol_merge) then
               b(k) = max(b(k), b(i))
            else
               nout = nout + 1
               a(nout) = a(i)
               b(nout) = b(i)
            end if
         end if
      end do
   end subroutine merge_intervals

end module conductivity_mod


module io_helpers_mod
   use precision, only : dp
   implicit none
   private

   public :: read_templist
   public :: read_selfenergy_file
   public :: read_omega_grid_file
   public :: extract_nonnegative_omega
   public :: make_selfenergy_filename, make_output_filename
   public :: write_sigma_output

contains

   subroutine read_templist(filename, temps, nt)
      character(len=*), intent(in) :: filename
      real(dp), allocatable, intent(out) :: temps(:)
      integer, intent(out) :: nt

      integer :: ios, i, unit
      real(dp) :: tmp

      nt = 0
      unit = 10

      open(unit=unit, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) error stop 'read_templist: cannot open file'

      do
         read(unit, *, iostat=ios) tmp
         if (ios /= 0) exit
         nt = nt + 1
      end do
      close(unit)

      if (nt <= 0) error stop 'read_templist: no temperatures found'

      allocate(temps(nt))

      open(unit=unit, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) error stop 'read_templist: cannot reopen file'

      do i = 1, nt
         read(unit, *) temps(i)
      end do
      close(unit)
   end subroutine read_templist

   subroutine read_selfenergy_file(filename, omega, sig_re, sig_im)
      character(len=*), intent(in) :: filename
      real(dp), allocatable, intent(out) :: omega(:), sig_re(:), sig_im(:)

      integer :: ios, i, n, unit
      real(dp) :: w, sr, si

      n = 0
      unit = 11

      open(unit=unit, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) error stop 'read_selfenergy_file: cannot open file'

      do
         read(unit, *, iostat=ios) w, sr, si
         if (ios /= 0) exit
         n = n + 1
      end do
      close(unit)

      if (n < 2) error stop 'read_selfenergy_file: too few data rows'

      allocate(omega(n), sig_re(n), sig_im(n))

      open(unit=unit, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) error stop 'read_selfenergy_file: cannot reopen file'

      do i = 1, n
         read(unit, *) omega(i), sig_re(i), sig_im(i)
      end do
      close(unit)
   end subroutine read_selfenergy_file

   subroutine read_omega_grid_file(filename, omega)
      character(len=*), intent(in) :: filename
      real(dp), allocatable, intent(out) :: omega(:)

      integer :: ios, i, n, unit
      real(dp) :: w

      n = 0
      unit = 13

      open(unit=unit, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) error stop 'read_omega_grid_file: cannot open file'

      do
         read(unit, *, iostat=ios) w
         if (ios /= 0) exit
         n = n + 1
      end do
      close(unit)

      if (n <= 0) error stop 'read_omega_grid_file: no omega points found'

      allocate(omega(n))

      open(unit=unit, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) error stop 'read_omega_grid_file: cannot reopen file'

      do i = 1, n
         read(unit, *) omega(i)
      end do
      close(unit)

      if (any(omega < 0.0_dp)) error stop 'read_omega_grid_file: omega grid must be nonnegative'

      do i = 2, n
         if (omega(i) <= omega(i-1)) error stop 'read_omega_grid_file: omega grid must be strictly increasing'
      end do
   end subroutine read_omega_grid_file

   subroutine extract_nonnegative_omega(omega_in, omega_pos, nw_pos)
      real(dp), intent(in) :: omega_in(:)
      real(dp), allocatable, intent(out) :: omega_pos(:)
      integer, intent(out) :: nw_pos

      integer :: i, j

      nw_pos = count(omega_in >= 0.0_dp)
      if (nw_pos <= 0) error stop 'extract_nonnegative_omega: no nonnegative omega points'

      allocate(omega_pos(nw_pos))
      j = 0
      do i = 1, size(omega_in)
         if (omega_in(i) >= 0.0_dp) then
            j = j + 1
            omega_pos(j) = omega_in(i)
         end if
      end do
   end subroutine extract_nonnegative_omega

   subroutine make_selfenergy_filename(temp, filename)
      real(dp), intent(in) :: temp
      character(len=*), intent(out) :: filename
      character(len=32) :: tag
      CHARACTER*7 handle                                     !suitbale for nca program

      ! Adjust this to your actual naming convention.
!      write(tag, '(ES14.6E3)') temp
      WRITE(handle,'(E7.2)') temp                            !suitable for nca program
!      filename = 'dos.dat_' // trim(adjustl(tag)) // '.dat'
      filename = 'dos.dat_'//handle                          !suitable for nca program
   end subroutine make_selfenergy_filename

   subroutine make_output_filename(temp, filename)
      real(dp), intent(in) :: temp
      character(len=*), intent(out) :: filename
      character(len=32) :: tag

      write(tag, '(ES14.6E3)') temp
      filename = 'sigma_' // trim(adjustl(tag)) // '.dat'
   end subroutine make_output_filename

   subroutine write_sigma_output(filename, omega, sigma)
      character(len=*), intent(in) :: filename
      real(dp), intent(in) :: omega(:), sigma(:)

      integer :: unit, ios, i

      if (size(omega) /= size(sigma)) error stop 'write_sigma_output: size mismatch'

      unit = 12
      open(unit=unit, file=filename, status='replace', action='write', iostat=ios)
      if (ios /= 0) error stop 'write_sigma_output: cannot open output file'

      do i = 1, size(omega)
         write(unit, '(2ES24.15E3)') omega(i), sigma(i)
      end do

      close(unit)
   end subroutine write_sigma_output

end module io_helpers_mod


program main_conductivity
   use precision, only : dp
   use thermal_distribution_module, only : set_thermal_beta
   use selfenergy_interp_mod, only : selfenergy_type, init_selfenergy, destroy_selfenergy
   use rhotilde_mod, only : rhotilde_type, init_rhotilde, destroy_rhotilde
   use spectral_mod, only : spectral_params_type
   use conductivity_mod, only : conductivity_params_type, sigma_re
   use io_helpers_mod, only : read_templist, read_selfenergy_file, read_omega_grid_file, &
                              extract_nonnegative_omega, make_selfenergy_filename, &
                              make_output_filename, write_sigma_output
   implicit none

   type(selfenergy_type) :: se_obj
   type(rhotilde_type) :: rt_obj
   type(spectral_params_type) :: sp
   type(conductivity_params_type) :: cp

   real(dp), allocatable :: temps(:)
   real(dp), allocatable :: omega_in(:), sig_re_in(:), sig_im_in(:)
   real(dp), allocatable :: omega_sigma(:), sigma_out(:)

   integer :: nt, it, i, nw_sigma
   real(dp) :: temp, beta
   logical, parameter :: use_external_omega_grid = .true.
   character(len=*), parameter :: omega_grid_file = 'OMEGA_GRID.dat'
   character(len=256) :: se_file, out_file

   ! ---------------- User parameters ----------------
   sp%eta = 0.2_dp
   sp%tau = 0.2_dp

   cp%t_hop = 0.2_dp

   cp%tol_total = 1.0e-6_dp
   cp%tol_eps   = 1.0e-9_dp         !Tolerance for the inner ϵ-integration
   cp%tol_nu    = 1.0e-8_dp      !Tolerance for the outer ν-integration
   cp%omega_dc_tol = 1.0e-10_dp   !Threshold below which the code stops using the finite-ω formula and switches to the special dc routine.
   cp%nu_cut_factor = 24.0_dp    !Factor controlling the size of the ν-integration window. The window is roughly nu_cut_factor / beta at finite temperature, and just nu_cut_factor at zero temperature.
   cp%eps_window_factor = 8.0_dp!Factor controlling the size of the ϵ-integration window around the spectral peaks. The window is roughly eps_window_factor times the peak width. Larger value means a wider ϵ-interval.
   cp%max_recursion = 40         !Maximum subdivision depth for adaptive Simpson. Larger value allows more refinement before the quadrature gives up subdividing.
   ! -------------------------------------------------

   call read_templist('TEMPLIST.dat', temps, nt)

   call init_rhotilde(rt_obj, t_hop=cp%t_hop, neps=4001, D=15.0_dp, xmax=300.0_dp, nx=40000, rho_floor=1.0d-14)

   do it = 1, nt
      temp = temps(it)
      if (temp <= 0.0_dp) cycle

      beta = 1.0_dp / temp
      call set_thermal_beta(beta)

      call make_selfenergy_filename(temp, se_file)
      call read_selfenergy_file(trim(se_file), omega_in, sig_re_in, sig_im_in)
      call init_selfenergy(se_obj, omega_in, sig_re_in, sig_im_in)

      if (use_external_omega_grid) then
         call read_omega_grid_file(trim(omega_grid_file), omega_sigma)
      else
         call extract_nonnegative_omega(omega_in, omega_sigma, nw_sigma)
      end if
      nw_sigma = size(omega_sigma)

      if (omega_sigma(1) < omega_in(1) .or. omega_sigma(nw_sigma) > omega_in(size(omega_in))) then
         error stop 'main_conductivity: requested omega grid lies outside self-energy grid range'
      end if

      allocate(sigma_out(nw_sigma))
      do i = 1, nw_sigma
         sigma_out(i) = -1.0_dp * sigma_re(omega_sigma(i), se_obj, rt_obj, sp, cp) ! overall minus sign seems to be required
      end do

      call make_output_filename(temp, out_file)
      call write_sigma_output(trim(out_file), omega_sigma, sigma_out)

      deallocate(sigma_out, omega_sigma, omega_in, sig_re_in, sig_im_in)
      call destroy_selfenergy(se_obj)
   end do

   call destroy_rhotilde(rt_obj)
   deallocate(temps)

end program main_conductivity
